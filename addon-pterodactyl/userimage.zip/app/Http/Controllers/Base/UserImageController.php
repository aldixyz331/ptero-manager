<?php

namespace Pterodactyl\Http\Controllers\Base;

use App\Http\Requests;
use Illuminate\View\View;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\facades\Auth;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class UserImageController extends Controller
{

    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    protected $alert;

    /**
     * StaffController constructor.
     * @param AlertsMessageBag $alert
     */
    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
     return view('base.userimage');
    }

    public function upload(Request $request, $id)
    {

        $this->validate($request, [
            'select_file'  => 'required|image|mimes:jpg,png,gif|max:2048'
        ]);

        $image = $request->file('select_file');

        $new_name = $id . '.' . $image->getClientOriginalExtension();

        DB::table('users')->where('id', '=', $id)->update([
        	'profileimage' => $new_name,
        ]);

        $image->move(public_path('images'), $new_name);
        $this->alert->success('ok')->flash();
        return back()->with('success', 'Image Uploaded Successfully')->with('path', $new_name);
    }

}
?>