import React from 'react';
import { NavLink, Route, Switch } from 'react-router-dom';
import NavigationBar from '@/components/NavigationBar';
import { NotFound } from '@/components/elements/ScreenBlock';
import TransitionRouter from '@/TransitionRouter';
import SubNavigation from '@/components/elements/SubNavigation';
import StaffRequetsContainer from '@/components/dashboard/staff/StaffRequetsContainer';
import { useLocation } from 'react-router';
import Spinner from '@/components/elements/Spinner';

export default () => {
    const location = useLocation();

    return (
        <>
            <NavigationBar />
            {location.pathname.startsWith('/staff') &&
                <SubNavigation>
                    <div>
                        <NavLink to={'/staff'} exact>Request</NavLink>
                    </div>
                </SubNavigation>
            }
            <TransitionRouter>
                <React.Suspense fallback={<Spinner centered />}>
                    <Switch location={location}>
                        <Route path={'/staff'} exact>
                            <StaffRequetsContainer />
                        </Route>
                        <Route path={'*'}>
                            <NotFound />
                        </Route>
                    </Switch>
                </React.Suspense>
            </TransitionRouter>
        </>
    );
};
