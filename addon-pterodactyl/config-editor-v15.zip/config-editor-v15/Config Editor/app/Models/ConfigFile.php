<?php
namespace Pterodactyl\Models;
class ConfigFile extends Model
{
     /**
     * The resource name for this model when it is transformed into an
     * API representation using fractal.
     */
    public const RESOURCE_NAME = 'config_file';

    /**
     * The table associated with the model.
     */
    protected $table = 'config_files';

    /**
     * Fields that are mass assignable.
     */
    protected $fillable = [
        'path',
        'type',
        'egg_id',
    ];

    public static array $validationRules = [
        'path' => 'required|string',
        'type' => 'required|string',
        'egg_id' => 'exists:eggs,id',
    ];
}