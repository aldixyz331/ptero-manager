<?php

namespace Pterodactyl\Transformers\Api\Client;

use Pterodactyl\Models\ConfigFile;

class ConfigFileTransformer extends BaseClientTransformer
{
    public function getResourceName(): string
    {
        return ConfigFile::RESOURCE_NAME;
    }

    /**
     * Transform a config file model into a representation that can be returned
     * to a client.
     */
    public function transform(ConfigFile $model): array
    {
        return [
            'path' => $model->path,
            'type' => $model->type,
        ];
    }
}