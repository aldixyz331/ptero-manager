import { httpErrorToHuman } from '@/api/http';
import saveFileContents from '@/api/server/files/saveFileContents';
import Button from '@/components/elements/Button';
import Can from '@/components/elements/Can';
import Input from '@/components/elements/Input';
import Label from '@/components/elements/Label';
import Switch from '@/components/elements/Switch';
import MessageBox from '@/components/MessageBox';
import GreyRowBox from '@/components/elements/GreyRowBox';
import { encodePathSegments, hashToPath } from '@/helpers';
import useFlash from '@/plugins/useFlash';
import { ServerContext } from '@/state/server';
import React, { useEffect, useState } from 'react';
import { useHistory, useLocation } from 'react-router';
import tw from 'twin.macro';
import { ConfigFile } from '@/api/server/getServer';
import styles from '../style.module.css';

interface Item {
    key: string | null;
    value: string | object | null;
    separator: string | null;
    originalIndex: number;
    isEmptyLine: boolean;
    comment: string | null;
    endsWithCharacter: string | null;
    enclosingQuote: string | null;
}

function parse(data: string) {
    const propertiesArray: Item[] = [];
    const lines = data.split('\n');

    lines.forEach((line, index) => {
        line = line.trimEnd();

        if (!line) {
            propertiesArray.push({
                key: null,
                value: null,
                separator: null,
                originalIndex: index,
                isEmptyLine: true,
                comment: null,
                endsWithCharacter: null,
                enclosingQuote: null,
            });
        } else if (
            line.startsWith('#') ||
            line.startsWith(';') ||
            line.startsWith('!') ||
            line.startsWith('[') ||
            line.startsWith('//') ||
            line.startsWith('class') ||
            line.startsWith('{') ||
            line.startsWith('}') ||
            line.startsWith(' ') ||
            line.startsWith('\t') ||
            line.startsWith('ensure') ||
            line.startsWith('motd[] = {')
        ) {
            propertiesArray.push({
                key: null,
                value: null,
                separator: null,
                originalIndex: index,
                isEmptyLine: false,
                comment: line,
                endsWithCharacter: null,
                enclosingQuote: null,
            });
        } else {
            const match = line.match(/\s[=:]\s|[=:]|\s/);
            if (match) {
                const separatorIndex = match.index!;
                const separator = match[0];
                const key = line.slice(0, separatorIndex).trim();
                let value = line.slice(separatorIndex + separator.length).trim();

                let endsWithCharacter: string | null = null;
                if (value.endsWith(';')) {
                    endsWithCharacter = ';';
                    value = value.slice(0, -1).trim();
                }

                let enclosingQuote: string | null = null;
                if (value.startsWith('"') && value.endsWith('"')) {
                    enclosingQuote = '"';
                    value = value.slice(1, -1);
                } else if (value.startsWith("'") && value.endsWith("'")) {
                    enclosingQuote = "'";
                    value = value.slice(1, -1);
                }

                propertiesArray.push({
                    key,
                    value,
                    separator,
                    originalIndex: index,
                    isEmptyLine: false,
                    comment: null,
                    endsWithCharacter,
                    enclosingQuote,
                });
            }
        }
    });

    return propertiesArray;
}

function convertToFileFormat(items: Item[]) {
    return items
        .map((item) => {
            if (item.isEmptyLine) {
                return '';
            }
            if (item.comment) {
                return item.comment;
            }
            let valueWithEnding = item.value || '';

            if (item.enclosingQuote) {
                valueWithEnding = `${item.enclosingQuote}${valueWithEnding}${item.enclosingQuote}`;
            }

            if (item.endsWithCharacter) {
                valueWithEnding += item.endsWithCharacter;
            }

            return `${item.key}${item.separator || ''}${valueWithEnding}`;
        })
        .join('\n');
}

interface Parameters {
    content: string;
    config: ConfigFile;
    setLoading: (v: boolean) => void;
}

export default ({ content, config, setLoading }: Parameters) => {
    const history = useHistory();
    const { hash } = useLocation();

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { addError, clearFlashes } = useFlash();

    const [items, setItems] = useState<Item[]>([]);
    const [search, setSearch] = useState('');

    const save = () => {
        setLoading(true);
        clearFlashes('files:view');

        saveFileContents(uuid, hashToPath(hash), convertToFileFormat(items))
            .catch((error) => {
                console.error(error);
                addError({ message: httpErrorToHuman(error), key: 'files:view' });
            })
            .then(() => setLoading(false));
    };

    function handleInputChange(originalIndex: number, newValue: string) {
        setItems((prevItems) =>
            prevItems.map((item, index) => (index === originalIndex ? { ...item, value: newValue } : item))
        );
    }

    useEffect(() => {
        const parsedItems = parse(content);
        setItems(parsedItems);
    }, [content]);

    return (
        <>
            <MessageBox type={'info'}>
                This is a CFG config file, CFG config files may contain commands, imports or ensures, which will still
                show up here, they can be edited, but their first word is seen as the label, in order to edit them
                properly you can edit the file manually by clicking the view file button below.
                <br />
                <br />
                NOTE: <code>#</code> can be used to add comments to configuration lines.
            </MessageBox>
            <div className={'flex flex-wrap-reverse md:flex-nowrap mb-4 mt-3'}>
                <h2
                    css={tw`flex flex-grow-0 items-center font-header text-2xl text-gray-50 leading-relaxed line-clamp-1`}
                >
                    {hash.substring(hash.lastIndexOf('/') + 1)}
                </h2>
                <div className={styles.manager_actions}>
                    <Button
                        onClick={() => history.push(`/server/${uuid}/files/edit#/${encodePathSegments(config.path)}`)}
                    >
                        View File
                    </Button>
                    <Button onClick={() => history.goBack()}>Back</Button>
                </div>
            </div>
            <Input placeholder={'Search...'} onChange={(e) => setSearch(e.currentTarget.value)} />
            <div css={tw`relative mt-4`}>
                <div className={'grid grid-cols-2 gap-3'}>
                    {!items || items.filter((item) => item.value && typeof item.value !== 'object').length === 0 ? (
                        <p css={tw`text-center col-span-2 text-sm text-neutral-300`}>
                            Looks like this configuration file does not have any editable values.
                        </p>
                    ) : (
                        items
                            .filter(
                                (item) =>
                                    item.key &&
                                    typeof item.value !== 'object' &&
                                    (item.key.toLowerCase().includes(search.toLowerCase()) ||
                                        String(item.value).toLowerCase().includes(search.toLowerCase()))
                            )
                            .map((item) => (
                                <GreyRowBox key={item.originalIndex} className='!block'>
                                    <Label>{item.key}</Label>
                                    {item.value === 'true' || item.value === 'false' ? (
                                        <div className='flex gap-2'>
                                            <Switch
                                                name={item.key!}
                                                onChange={(e) =>
                                                    handleInputChange(
                                                        item.originalIndex,
                                                        String(e.currentTarget.checked)
                                                    )
                                                }
                                                defaultChecked={item.value === 'true'}
                                            />
                                            <p>{item.value === 'true' ? 'Enabled' : 'Disabled'}</p>
                                        </div>
                                    ) : (
                                        <Input
                                            type={'text'}
                                            value={`${item.value}`}
                                            onChange={(e) => handleInputChange(item.originalIndex, e.target.value)}
                                        />
                                    )}
                                </GreyRowBox>
                            ))
                    )}
                </div>
            </div>
            {items && items.filter((item) => item.value && typeof item.value !== 'object').length > 0 && (
                <div css={tw`flex justify-end mt-4`}>
                    <Can action={'file.update'}>
                        <Button css={tw`flex-1 sm:flex-none`} onClick={() => save()}>
                            Save
                        </Button>
                    </Can>
                </div>
            )}
        </>
    );
};