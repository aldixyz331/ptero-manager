import { httpErrorToHuman } from '@/api/http';
import saveFileContents from '@/api/server/files/saveFileContents';
import { ConfigFile } from '@/api/server/getServer';
import Button from '@/components/elements/Button';
import Can from '@/components/elements/Can';
import Input from '@/components/elements/Input';
import Label from '@/components/elements/Label';
import Switch from '@/components/elements/Switch';
import GreyRowBox from '@/components/elements/GreyRowBox';
import MessageBox from '@/components/MessageBox';
import { encodePathSegments, hashToPath } from '@/helpers';
import useFlash from '@/plugins/useFlash';
import { ServerContext } from '@/state/server';
import React, { useEffect, useState } from 'react';
import { useHistory, useLocation } from 'react-router';
import tw from 'twin.macro';
import styles from '../style.module.css';

interface Item {
    key: string | null;
    value: string | object | number | string[] | number[] | boolean | null;
}

function parse(data: string) {
    const propertiesArray = [];
    const jsonObject = JSON.parse(data);

    for (const [key, value] of Object.entries(jsonObject)) {
        propertiesArray.push({
            key: String(key),
            value: typeof value === 'object' && value !== null ? value : String(value),
        });
    }

    return propertiesArray;
}

function convertToFileFormat(items: Item[]) {
    const jsonObject: { [key: string]: any } = {};

    items.forEach((item) => {
        if (item.key) jsonObject[item.key] = item.value;
    });

    return JSON.stringify(jsonObject, null, 2);
}

interface Parameters {
    content: string;
    config: ConfigFile;
    setLoading: (v: boolean) => void;
}

export default ({ content, config, setLoading }: Parameters) => {
    const history = useHistory();
    const { hash } = useLocation();

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { addError, clearFlashes } = useFlash();

    const [items, setItems] = useState<Item[]>([]);
    const [search, setSearch] = useState('');

    const save = () => {
        setLoading(true);
        clearFlashes('files:view');

        saveFileContents(uuid, hashToPath(hash), convertToFileFormat(items))
            .catch((error) => {
                console.error(error);
                addError({ message: httpErrorToHuman(error), key: 'files:view' });
            })
            .then(() => setLoading(false));
    };

    function handleInputChange(originalIndex: number, newValue: string | number | string[] | number[] | boolean) {
        setItems((prevItems) =>
            prevItems.map((item, index) => (index === originalIndex ? { ...item, value: newValue } : item))
        );
    }

    useEffect(() => {
        if (!content) return;
        const parsedItems = parse(content);
        setItems(parsedItems);
    }, [content]);

    return (
        <>
            <MessageBox type={'info'}>
                This is a JSON config file, json config files may contain nested configurations which will not show up
                here, in order to edit those you can edit the file manually by clicking the view file button below.
            </MessageBox>
            <div className={'flex flex-wrap-reverse md:flex-nowrap mb-4 mt-3'}>
                <h2
                    css={tw`flex flex-grow-0 items-center font-header text-2xl text-gray-50 leading-relaxed line-clamp-1`}
                >
                    {hash.substring(hash.lastIndexOf('/') + 1)}
                </h2>
                <div className={styles.manager_actions}>
                    <Button
                        onClick={() => history.push(`/server/${uuid}/files/edit#/${encodePathSegments(config.path)}`)}
                    >
                        View File
                    </Button>
                    <Button onClick={() => history.goBack()}>Back</Button>
                </div>
            </div>
            <Input placeholder={'Search...'} onChange={(e) => setSearch(e.currentTarget.value)} />
            <div css={tw`relative mt-4`}>
                <div className={'grid grid-cols-2 gap-3'}>
                    {!items || items.filter((item) => item.value && typeof item.value !== 'object').length === 0 ? (
                        <p css={tw`text-center col-span-2 text-sm text-neutral-300`}>
                            Looks like this configuration file does not have any editable values.
                        </p>
                    ) : (
                        items
                            .filter(
                                (item) =>
                                    item.key &&
                                    (typeof item.value !== 'object' || Array.isArray(item.value)) &&
                                    (item.key.toLowerCase().includes(search.toLowerCase()) ||
                                        String(item.value).toLowerCase().includes(search.toLowerCase()))
                            )
                            .map((item, index: number) => (
                                <GreyRowBox key={index} className='!block'>
                                    <Label>{item.key}</Label>
                                    {item.value === 'true' ||
                                    item.value === 'false' ||
                                    item.value === true ||
                                    item.value === false ? (
                                        <div className='flex gap-2'>
                                            <Switch
                                                name={item.key!}
                                                onChange={(e) => handleInputChange(index, e.currentTarget.checked)}
                                                defaultChecked={item.value === 'true'}
                                            />
                                            <p>
                                                {item.value === 'true' || item.value === true ? 'Enabled' : 'Disabled'}
                                            </p>
                                        </div>
                                    ) : (
                                        <Input
                                            type={'text'}
                                            value={`${Array.isArray(item.value) ? item.value.join(', ') : item.value}`}
                                            onChange={(e) => {
                                                const value = Array.isArray(item.value)
                                                    ? e.target.value
                                                          .split(', ')
                                                          .map((val: any) => (isNaN(val) ? val : Number(val)))
                                                    : isNaN(e.target.value as any)
                                                    ? e.target.value
                                                    : Number(e.target.value);
                                                handleInputChange(index, value);
                                            }}
                                        />
                                    )}
                                </GreyRowBox>
                            ))
                    )}
                </div>
            </div>
            {items &&
                items.filter((item) => item.key && (typeof item.value !== 'object' || Array.isArray(item.value)))
                    .length > 0 && (
                    <div css={tw`flex justify-end mt-4`}>
                        <Can action={'file.update'}>
                            <Button css={tw`flex-1 sm:flex-none`} onClick={() => save()}>
                                Save
                            </Button>
                        </Can>
                    </div>
                )}
        </>
    );
};