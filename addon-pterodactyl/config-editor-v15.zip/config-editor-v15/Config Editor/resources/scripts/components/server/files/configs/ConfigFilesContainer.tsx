import { Button } from '@/components/elements/button/index';
import Can from '@/components/elements/Can';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import Spinner from '@/components/elements/Spinner';
import { encodePathSegments } from '@/helpers';
import { ServerContext } from '@/state/server';
import { faFileAlt } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';
import { NavLink, useHistory } from 'react-router-dom';
import { CSSTransition } from 'react-transition-group';
import tw from 'twin.macro';
import styles from '../style.module.css';

export default () => {
    const history = useHistory();

    const id = ServerContext.useStoreState((state) => state.server.data!.id);
    const eggConfigs = ServerContext.useStoreState((state) => state.server.data!.eggConfigs);

    return (
        <ServerContentBlock title={'File Manager'} showFlashKey={'files'}>
            <div className={'flex flex-wrap-reverse md:flex-nowrap mb-4'}>
                <h2
                    css={tw`flex flex-grow-0 items-center font-header text-2xl text-gray-50 leading-relaxed line-clamp-1`}
                >
                    Config Files
                </h2>
                <Can action={'file.create'}>
                    <div className={styles.manager_actions}>
                        <Button onClick={() => history.goBack()}>Back</Button>
                    </div>
                </Can>
            </div>
            {!eggConfigs ? (
                <Spinner size={'large'} centered />
            ) : (
                <>
                    {!eggConfigs.length ? (
                        <p css={tw`text-sm text-neutral-400 text-center`}>
                            No config files could be found for this server.
                        </p>
                    ) : (
                        <CSSTransition classNames={'fade'} timeout={150} appear in>
                            <div>
                                {eggConfigs.map((file, index) => (
                                    <div key={index} className={styles.file_row}>
                                        <NavLink
                                            className={styles.details}
                                            to={`/server/${id}/files/configs/edit#/${encodePathSegments(file.path)}`}
                                        >
                                            <div css={tw`flex-none text-neutral-400 ml-6 mr-4 text-lg pl-3`}>
                                                <FontAwesomeIcon icon={faFileAlt} />
                                            </div>
                                            <div css={tw`flex-1 truncate`}>{file.path}</div>
                                        </NavLink>
                                    </div>
                                ))}
                            </div>
                        </CSSTransition>
                    )}
                </>
            )}
        </ServerContentBlock>
    );
};
