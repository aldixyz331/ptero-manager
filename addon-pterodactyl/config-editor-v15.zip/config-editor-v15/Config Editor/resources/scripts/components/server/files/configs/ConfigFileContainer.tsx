import { httpErrorToHuman } from '@/api/http';
import getFileContents from '@/api/server/files/getFileContents';
import saveFileContents from '@/api/server/files/saveFileContents';
import { ConfigFile } from '@/api/server/getServer';
import Button from '@/components/elements/Button';
import GreyRowBox from '@/components/elements/GreyRowBox';
import Can from '@/components/elements/Can';
import Input from '@/components/elements/Input';
import Label from '@/components/elements/Label';
import PageContentBlock from '@/components/elements/PageContentBlock';
import { ServerError } from '@/components/elements/ScreenBlock';
import Switch from '@/components/elements/Switch';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import FlashMessageRender from '@/components/FlashMessageRender';
import CfgConfigFileContainer from '@/components/server/files/configs/CfgConfigFileContainer';
import JsonConfigFileContainer from '@/components/server/files/configs/JsonConfigFileContainer';
import YmlConfigFileContainer from '@/components/server/files/configs/YmlConfigFileContainer';
import { encodePathSegments, hashToPath } from '@/helpers';
import useFlash from '@/plugins/useFlash';
import { ServerContext } from '@/state/server';
import React, { useEffect, useState } from 'react';
import { useHistory, useLocation, useParams } from 'react-router';
import tw from 'twin.macro';
import styles from '../style.module.css';

interface Item {
    key: string | null;
    value: string | object | null;
    separator: string | null;
    originalIndex: number;
    isEmptyLine: boolean;
    comment: string | null;
    enclosingQuote: string | null;
}

function parse(data: string) {
    const propertiesArray: Item[] = [];
    const lines = data.split('\n');

    lines.forEach((line, index) => {
        line = line.trimEnd();

        if (!line) {
            propertiesArray.push({
                key: null,
                value: null,
                separator: null,
                originalIndex: index,
                isEmptyLine: true,
                comment: null,
                enclosingQuote: null,
            });
        } else if (
            line.startsWith('#') ||
            line.startsWith(';') ||
            line.startsWith('!') ||
            line.startsWith('[') ||
            line.startsWith('//')
        ) {
            propertiesArray.push({
                key: null,
                value: null,
                separator: null,
                originalIndex: index,
                isEmptyLine: false,
                comment: line,
                enclosingQuote: null,
            });
        } else {
            const match = line.match(/\s[=:]\s|[=:]|\s/);
            if (match) {
                const separatorIndex = match.index!;
                const separator = match[0];
                const key = line.slice(0, separatorIndex).trim();
                let value = line.slice(separatorIndex + separator.length).trim();

                let enclosingQuote: string | null = null;
                if (value.startsWith('"') && value.endsWith('"')) {
                    enclosingQuote = '"';
                    value = value.slice(1, -1);
                } else if (value.startsWith("'") && value.endsWith("'")) {
                    enclosingQuote = "'";
                    value = value.slice(1, -1);
                }

                propertiesArray.push({
                    key,
                    value,
                    separator,
                    originalIndex: index,
                    isEmptyLine: false,
                    comment: null,
                    enclosingQuote,
                });
            }
        }
    });

    return propertiesArray;
}

function convertToFileFormat(items: Item[]) {
    return items
        .map((item) => {
            if (item.isEmptyLine) {
                return '';
            }
            if (item.comment) {
                return item.comment;
            }
            let valueWithEnding = item.value || '';

            if (item.enclosingQuote) {
                valueWithEnding = `${item.enclosingQuote}${valueWithEnding}${item.enclosingQuote}`;
            }

            return `${item.key}${item.separator || ''}${valueWithEnding}`;
        })
        .join('\n');
}

export default () => {
    const [error, setError] = useState('');
    const { action } = useParams<{ action: 'new' | string }>();
    const [loading, setLoading] = useState(action === 'edit');

    const history = useHistory();
    const { hash } = useLocation();

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const eggConfigs = ServerContext.useStoreState((state) => state.server.data!.eggConfigs);
    const { addError, clearFlashes } = useFlash();

    const [items, setItems] = useState<Item[]>([]);
    const [eggConfig, setEggConfig] = useState<ConfigFile>();
    const [content, setContent] = useState('');
    const [search, setSearch] = useState('');

    useEffect(() => {
        setError('');
        setLoading(true);

        const path = hashToPath(hash);
        let config: ConfigFile;
        eggConfigs.forEach((configFile) => {
            if ('/' + configFile.path === path) config = configFile;
        });
        setEggConfig(config!);

        getFileContents(uuid, path)
            .then((content) => {
                setContent(content);
                let items: Item[];
                if (config.type === 'properties' || config.type === 'ini' || config.type === 'env') {
                    items = parse(content);
                }

                setItems(items!);
            })
            .catch((error) => {
                console.error(error);
                setError(httpErrorToHuman(error));
            })
            .then(() => setLoading(false));
    }, [action, uuid, hash]);

    const save = () => {
        setLoading(true);
        clearFlashes('files:view');

        if (!eggConfig) return;

        let content = '';
        if (eggConfig.type === 'properties' || eggConfig.type === 'ini' || eggConfig.type === 'env')
            content = convertToFileFormat(items);

        saveFileContents(uuid, hashToPath(hash), content)
            .catch((error) => {
                console.error(error);
                addError({ message: httpErrorToHuman(error), key: 'files:view' });
            })
            .then(() => setLoading(false));
    };

    function handleInputChange(originalIndex: number, newValue: string) {
        setItems((prevItems) =>
            prevItems.map((item, index) => (index === originalIndex ? { ...item, value: newValue } : item))
        );
    }

    if (error) {
        return <ServerError message={error} onBack={() => history.goBack()} />;
    }

    return (
        <PageContentBlock>
            <SpinnerOverlay visible={loading} fixed />
            <FlashMessageRender byKey={'files:view'} css={tw`mb-4`} />
            {eggConfig &&
                (eggConfig.type === 'yml' ? (
                    <YmlConfigFileContainer setLoading={setLoading} content={content} config={eggConfig} />
                ) : eggConfig.type === 'json' ? (
                    <JsonConfigFileContainer setLoading={setLoading} content={content} config={eggConfig} />
                ) : eggConfig.type === 'cfg' ? (
                    <CfgConfigFileContainer setLoading={setLoading} content={content} config={eggConfig} />
                ) : (
                    <>
                        <div className={'flex flex-wrap-reverse md:flex-nowrap mb-4'}>
                            <h2
                                css={tw`flex flex-grow-0 items-center font-header text-2xl text-gray-50 leading-relaxed line-clamp-1`}
                            >
                                {hash.substring(hash.lastIndexOf('/') + 1)}
                            </h2>
                            <div className={styles.manager_actions}>
                                <Button
                                    onClick={() =>
                                        history.push(
                                            `/server/${uuid}/files/edit#/${encodePathSegments(eggConfig.path)}`
                                        )
                                    }
                                >
                                    View File
                                </Button>
                                <Button onClick={() => history.goBack()}>Back</Button>
                            </div>
                        </div>
                        <Input placeholder={'Search...'} onChange={(e) => setSearch(e.currentTarget.value)} />
                        <div css={tw`relative mt-4`}>
                            <div className='grid grid-cols-2 gap-3 items-stretch'>
                                {!items ||
                                items.filter((item) => item.value && typeof item.value !== 'object').length === 0 ? (
                                    <p css={tw`text-center col-span-2 text-sm text-neutral-300`}>
                                        Looks like this configuration file does not have any editable values.
                                    </p>
                                ) : (
                                    items
                                        .filter(
                                            (item) =>
                                                item.key &&
                                                typeof item.value !== 'object' &&
                                                (item.key.toLowerCase().includes(search.toLowerCase()) ||
                                                    String(item.value).toLowerCase().includes(search.toLowerCase()))
                                        )
                                        .map((item) => (
                                            <GreyRowBox key={item.originalIndex} className='!block'>
                                                <Label>{item.key}</Label>
                                                {item.value === 'true' || item.value === 'false' ? (
                                                    <div className='flex gap-2'>
                                                        <Switch
                                                            name={item.key!}
                                                            onChange={(e) =>
                                                                handleInputChange(
                                                                    item.originalIndex,
                                                                    String(e.currentTarget.checked)
                                                                )
                                                            }
                                                            defaultChecked={item.value === 'true'}
                                                        />
                                                        <p>{item.value === 'true' ? 'Enabled' : 'Disabled'}</p>
                                                    </div>
                                                ) : (
                                                    <Input
                                                        type={'text'}
                                                        value={`${item.value}`}
                                                        onChange={(e) =>
                                                            handleInputChange(item.originalIndex, e.target.value)
                                                        }
                                                    />
                                                )}
                                            </GreyRowBox>
                                        ))
                                )}
                            </div>
                        </div>
                        {items && items.filter((item) => item.value && typeof item.value !== 'object').length > 0 && (
                            <div css={tw`flex justify-end mt-4`}>
                                <Can action={'file.update'}>
                                    <Button css={tw`flex-1 sm:flex-none`} onClick={() => save()}>
                                        Save
                                    </Button>
                                </Can>
                            </div>
                        )}
                    </>
                ))}
        </PageContentBlock>
    );
};