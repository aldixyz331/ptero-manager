import { httpErrorToHuman } from '@/api/http';
import saveFileContents from '@/api/server/files/saveFileContents';
import { ConfigFile } from '@/api/server/getServer';
import Button from '@/components/elements/Button';
import Can from '@/components/elements/Can';
import Input from '@/components/elements/Input';
import Label from '@/components/elements/Label';
import Switch from '@/components/elements/Switch';
import GreyRowBox from '@/components/elements/GreyRowBox';
import { encodePathSegments, hashToPath } from '@/helpers';
import useFlash from '@/plugins/useFlash';
import { ServerContext } from '@/state/server';
import React, { useEffect, useState } from 'react';
import { useHistory, useLocation } from 'react-router';
import tw from 'twin.macro';
import styles from '../style.module.css';

interface Item {
    key: string | null;
    value: string | object | null;
    indent: string | null;
    originalIndex: number | null;
    isEmptyLine: boolean;
    comment: string | null;
}

function parse(data: string) {
    const propertiesArray: Item[] = [];
    const lines = data.split('\n');
    lines.forEach((line, index) => {
        const originalLine = line;
        const trimmedLine = line.trimEnd();

        if (!trimmedLine) {
            propertiesArray.push({
                key: null,
                value: null,
                indent: '',
                originalIndex: index,
                isEmptyLine: true,
                comment: null,
            });
        } else if (trimmedLine.startsWith('#')) {
            propertiesArray.push({
                key: null,
                value: null,
                indent: '',
                originalIndex: index,
                isEmptyLine: false,
                comment: trimmedLine,
            });
        } else {
            const indentMatch = originalLine.match(/^(\s*)/);
            const indent = indentMatch ? indentMatch[1] : '';

            const colonIndex = trimmedLine.indexOf(':');

            if (colonIndex !== -1) {
                const key = trimmedLine.slice(0, colonIndex).trim();
                let value: string | null = trimmedLine.slice(colonIndex + 1).trim();

                if (value === '') value = null;

                propertiesArray.push({
                    key,
                    value,
                    indent,
                    originalIndex: index,
                    isEmptyLine: false,
                    comment: null,
                });
            } else {
                propertiesArray.push({
                    key: trimmedLine.trim(),
                    value: null,
                    indent,
                    originalIndex: index,
                    isEmptyLine: false,
                    comment: null,
                });
            }
        }
    });

    return propertiesArray;
}

function convertToFileFormat(items: Item[]) {
    return items
        .map((item) => {
            if (item.isEmptyLine) {
                return '';
            }
            if (item.comment) {
                return item.comment;
            }

            const indent = item.indent || '';
            const key = item.key || '';
            const value = item.value !== null ? `: ${item.value}` : item.key?.startsWith('-') ? '' : ':';

            return `${indent}${key}${value}`;
        })
        .join('\n');
}

interface Parameters {
    content: string;
    config: ConfigFile;
    setLoading: (v: boolean) => void;
}

export default ({ content, config, setLoading }: Parameters) => {
    const history = useHistory();
    const { hash } = useLocation();

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { addError, clearFlashes } = useFlash();

    const [items, setItems] = useState<Item[]>([]);
    const [search, setSearch] = useState('');

    const save = () => {
        setLoading(true);
        clearFlashes('files:view');

        saveFileContents(uuid, hashToPath(hash), convertToFileFormat(items))
            .catch((error) => {
                console.error(error);
                addError({ message: httpErrorToHuman(error), key: 'files:view' });
            })
            .then(() => setLoading(false));
    };

    function handleInputChange(originalIndex: number, newValue: string) {
        setItems((prevItems) =>
            prevItems.map((item, index) => (index === originalIndex ? { ...item, value: newValue } : item))
        );
    }

    useEffect(() => {
        const parsedItems = parse(content);
        setItems(parsedItems);
    }, [content]);

    return (
        <>
            <div className={'flex flex-wrap-reverse md:flex-nowrap mb-4'}>
                <h2
                    css={tw`flex flex-grow-0 items-center font-header text-2xl text-gray-50 leading-relaxed line-clamp-1`}
                >
                    {hash.substring(hash.lastIndexOf('/') + 1)}
                </h2>
                <div className={styles.manager_actions}>
                    <Button
                        onClick={() => history.push(`/server/${uuid}/files/edit#/${encodePathSegments(config.path)}`)}
                    >
                        View File
                    </Button>
                    <Button onClick={() => history.goBack()}>Back</Button>
                </div>
            </div>
            <Input placeholder={'Search...'} onChange={(e) => setSearch(e.currentTarget.value)} />
            <div css={tw`relative mt-4`}>
                <div className={'grid grid-cols-2 gap-3'}>
                    {!items || items.filter((item) => item.value && typeof item.value !== 'object').length === 0 ? (
                        <p css={tw`text-center col-span-2 text-sm text-neutral-300`}>
                            Looks like this configuration file does not have any editable values.
                        </p>
                    ) : (
                        items
                            .filter(
                                (item) =>
                                    item.key &&
                                    typeof item.value !== 'object' &&
                                    (item.key.toLowerCase().includes(search.toLowerCase()) ||
                                        String(item.value).toLowerCase().includes(search.toLowerCase()))
                            )
                            .map((item, index: number) => (
                                <GreyRowBox key={index} className='!block'>
                                    <Label>{item.key}</Label>
                                    {item.value === 'true' || item.value === 'false' ? (
                                        <div className='flex gap-2'>
                                            <Switch
                                                name={item.key!}
                                                onChange={(e) =>
                                                    handleInputChange(
                                                        item.originalIndex ?? index,
                                                        String(e.currentTarget.checked)
                                                    )
                                                }
                                                defaultChecked={item.value === 'true'}
                                            />
                                            <p>{item.value === 'true' ? 'Enabled' : 'Disabled'}</p>
                                        </div>
                                    ) : (
                                        <Input
                                            type={'text'}
                                            value={`${item.value}`}
                                            onChange={(e) =>
                                                handleInputChange(item.originalIndex ?? index, e.target.value)
                                            }
                                        />
                                    )}
                                </GreyRowBox>
                            ))
                    )}
                </div>
            </div>
            {items && items.filter((item) => item.value && typeof item.value !== 'object').length > 0 && (
                <div css={tw`flex justify-end mt-4`}>
                    <Can action={'file.update'}>
                        <Button css={tw`flex-1 sm:flex-none`} onClick={() => save()}>
                            Save
                        </Button>
                    </Can>
                </div>
            )}
        </>
    );
};