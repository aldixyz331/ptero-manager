**Resource buyer - saybe | Cracked by NetStormer | Leaked on Black-Minecraft.com**

# Uploading the addon

1. Upload the "PANEL" folder to your pterodactyl installation directory.
2. Do `php artisan migrate`

# Edit User Model 

1. Open file `app/Models/User.php`
2. Find the following code:
```php
 * @property int|null $ssh_keys_count
 * @property \Illuminate\Database\Eloquent\Collection|\Pterodactyl\Models\ApiKey[] $tokens
 * @property int|null $tokens_count
```

3. Add the following code below:
```php
 * @property string $discord_id
 * @property string $discord_username
```

4. Find the following code :
```php
        'totp_authenticated_at',
        'gravatar',
        'root_admin',
```

5. Add the following code below:
```php
        'discord_id',
        'discord_username',
```

# Edit App 

1. Open file `resources/scripts/components/App.tsx`
2. Find the following code:
```js
        language: string;
        updated_at: string;
        created_at: string;
```

3. Add the following code below:
```js
        discord_username: string;
```

4. Find the following code:
```js
            useTotp: PterodactylUser.use_totp,
            createdAt: new Date(PterodactylUser.created_at),
            updatedAt: new Date(PterodactylUser.updated_at),
```

5. Add the following code below:
```js
            discordDisplayname: PterodactylUser.discord_username,
```


# Edit Login Container

1. Open file `resources/scripts/components/auth/LoginContainer.tsx`
2. Find the following code :
```tsx
                            Forgot password?
                        </Link>
                    </div>
```

4. Add the following code below:
```tsx
                    <div css={tw`mt-6 text-center`}>
                        <a
                            href={'/auth/discord/login'}
                            css={tw`text-xs text-neutral-500 tracking-wide no-underline uppercase hover:text-neutral-600 underline`}
                        >
                            Login with Discord
                        </a>
                    </div>
```

# Edit account overview

1. Open file `resources/scripts/components/dashboard/AccountOverviewContainer.tsx`
2. Under all the imports add the following code:
```tsx
import DiscordLoginBox from './DiscordLoginBox';
```

3. Find the following code:
```tsx
                <ContentBox css={tw`md:ml-8 mt-8 md:mt-0`} title={'Two-Step Verification'}>
                    <ConfigureTwoFactorForm />
                </ContentBox>
```

4. Add the following code below:
```tsx
                <ContentBox css={tw`mt-8 md:mt-2`} title={'Discord'}>
                    <DiscordLoginBox />
                </ContentBox>
```

# Edit user state typescript

1. Open file `resources/scripts/state/user.ts`
2. Find the following code:
```tsx
    useTotp: boolean;
    createdAt: Date;
    updatedAt: Date;
```

3. Add the following code below:
```tsx
    discordDisplayname: string;
```

# Edit admin layout

1. Open file `resources/views/layouts/admin.blade.php`
2. Find the following code:
```html
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.api') ?: 'active' }}">
                            <a href="{{ route('admin.api.index')}}">
                                <i class="fa fa-gamepad"></i> <span>Application API</span>
                            </a>
                        </li>
```

3. Add the following code below:
```html
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.myplugins.discord_auth') ?: 'active' }}">
                            <a href="{{ route('admin.myplugins.discord_auth') }}">
                                <i class="fa fa-share-square"></i> <span>Discord Auth</span>
                            </a>
                        </li>
```

# Edit admin routes

1. Open file `routes/admin.php`
2. At the bottom of the file add the following code:
```php
/*
|--------------------------------------------------------------------------
| MyPlugins Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /admin/myplugins
|
*/
Route::group(['prefix' => 'myplugins'], function () {
    Route::get('/discord_auth', [Admin\MyPlugins\DiscordAuthController::class, 'index'])->name('admin.myplugins.discord_auth');
    Route::patch('/discord_auth', [Admin\MyPlugins\DiscordAuthController::class, 'update']);
});
```

# Edit Client API routes

1. Open file `routes/api-client.php`
2. Under all use statements add the following code:
```php
use Pterodactyl\Http\Controllers\Auth\DiscordLogin;
```

3. Find the following code (don't miss the parentheses):
```php
        Route::post('/reinstall', [Client\Servers\SettingsController::class, 'reinstall']);
        Route::put('/docker-image', [Client\Servers\SettingsController::class, 'dockerImage']);
    });
});
```

4. Add the following code below:
```php
    Route::get('/discord/callback', [DiscordLogin::class, 'callback'])->name('auth.discord.callback')->withoutMiddleware('auth');
```

# Edit Auth routes

1. Open file `routes/auth.php`
2. Under all use statements add the following code:
```php
use Pterodactyl\Http\Controllers\Auth\DiscordLogin;
```

3. Find the following code:
```php
Route::post('/password/reset', Auth\ResetPasswordController::class)->name('auth.reset-password');
```

4. Add the following code below:
```php
Route::get('/discord/login', [DiscordLogin::class, 'login'])->name('auth.discord.login');
```

# Edit base routes

1. Open file `routes/base.php`
2. Under all use statements add the following code:
```php
use Pterodactyl\Http\Controllers\Auth\DiscordLogin;
```

3. Find the following code:
```php
    ->where('react', '^(?!(\/)?(api|auth|admin|daemon)).+');
```

4. Replace it with the following code:
```php
    ->where('react', '^(?!(\/)?(api|auth|admin|daemon|discord)).+');
```

5. Add the following code at the bottom of the file:
```php
Route::get('/discord/redirect', [DiscordLogin::class, 'redirect'])->name('auth.discord.redirect')->withoutMiddleware('auth');
```

# Build the panel

Follow the instructions on the [Pterodactyl Docs](https://pterodactyl.io/community/customization/panel.html) to build the panel.

# You are done!
