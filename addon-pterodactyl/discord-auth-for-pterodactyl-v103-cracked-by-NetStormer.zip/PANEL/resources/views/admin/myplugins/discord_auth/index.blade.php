@extends('layouts.admin')

@section('title')
    Discord Auth
@endsection

@section('content-header')
    <h1>Discord Auth<small>This part allows you to configure this addon.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li>Cracked by NetStormer</li>
        <li class="active">Discord Auth</li>
    </ol>
@endsection

@section('content')
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title">Discord Auth</h3>
                </div>
                <div class="box-body">
                    <p>Discord Auth was cracked <i class="fa fa-heart"></i> by NetStormer</p>
                    <p><strong>Resource buyer - saybe | Cracked by NetStormer | Leaked on Black-Minecraft.com</strong></p>
                </div>
            </div>
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Settings</h3>
                </div>
                <div class="box-body">
                    <div class="box-body table-responsive no-padding">
                        <p>Your redirect url is <strong>{{ $redirect }}</strong> and <strong>{{ $login }}</strong></p>
                        <form method="post">
                            @method('PATCH')
                            {{-- enabled switch --}}
                            <div class="form-group col-xs-12">
                                <label class="control-label">Enabled</label>
                                <div>
                                    <input type="text" class="form-control" name="enabled" value="{{ ($config->enabled) ? 'true' : 'false' }}">
                                </div>
                            </div>

                            {{-- client id --}}
                            <div class="form-group col-xs-6">
                                <label class="control-label">Client ID</label>
                                <div>
                                    <input type="text" class="form-control" name="client_id" value="{{ $config->client_id }}">
                                </div>
                            </div>
                            {{-- client secret --}}
                            <div class="form-group col-xs-6">
                                <label class="control-label">Client Secret</label>
                                <div>
                                    <input type="text" class="form-control" name="client_secret" value="{{ $config->client_secret }}" min="0" step="1">
                                </div>
                            </div>
                            <div class="form-group col-xs-12">
                                <div>
                                    {!! csrf_field() !!}
                                    <button type="submit" class="btn btn-sm btn-primary pull-right">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection