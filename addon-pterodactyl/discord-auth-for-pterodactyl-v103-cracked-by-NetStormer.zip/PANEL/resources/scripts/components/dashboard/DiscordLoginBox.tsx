import React from 'react';
import { State, useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import tw from 'twin.macro';

export default () => {
    const user = useStoreState((state: State<ApplicationStore>) => state.user.data);
    const displayname = useStoreState((state: State<ApplicationStore>) => state.user.data?.discordDisplayname);

    if (!user) {
        return null;
    }

    return (
        <React.Fragment>
            <div css={tw`m-0`}>
                <div css={tw`flex items-center`}>
                    <div css={tw`flex-1`}>
                        <h3 css={tw`text-2xl`}>Discord</h3>
                        <p css={tw`text-sm`}>
                            Link your Discord account to your Pterodactyl account to login using Discord.
                        </p>
                    </div>
                </div>
                <div css={tw`mt-6`}>
                    {displayname ? (
                        <p css={tw`text-sm`}>Your Discord account is currently linked as <strong>{displayname}</strong>.</p>
                    ) : (
                        <p css={tw`text-sm`}>Your Discord account is not currently linked.</p>
                    )}
                </div>
                <div css={tw`mt-6`}>
                    <a href={'/discord/redirect'} css={tw`relative inline-block rounded p-2 uppercase tracking-wide text-sm transition-all duration-150 bg-primary-600 text-primary-50`}> Link Discord Account </a>
                </div>
            </div>
        </React.Fragment>
    );
};