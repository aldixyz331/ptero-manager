<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('discord_auth_config', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('key')->unique();
            $table->string('value');
            $table->timestamps();
        });

        DB::table('discord_auth_config')->insert([
            'key' => 'enabled',
            'value' => '0',
        ]);

        DB::table('discord_auth_config')->insert([
            'key' => 'client_id',
            'value' => '',
        ]);

        DB::table('discord_auth_config')->insert([
            'key' => 'client_secret',
            'value' => '',
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('discord_auth_config');
    }
};