<?php

namespace Pterodactyl\Http\Controllers\Auth;

use Illuminate\Http\Request;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\discordAuthConfig;
use Pterodactyl\Models\User;

class DiscordLogin extends Controller
{
    /**
     * Callback for Discord OAuth2
     */
    public function callback(Request $request)
    {
        $code = $request->input('code');
        $state = $request->input('state');

        $config = discordAuthConfig::getAuthConfig();

        $client_id = $config->client_id;
        $client_secret = $config->client_secret;
        $redirect = route('auth.discord.callback');

        $url = 'https://discord.com/api/oauth2/token';

        $data = [
            'client_id' => $client_id,
            'client_secret' => $client_secret,
            'grant_type' => 'authorization_code',
            'code' => $code,
            'redirect_uri' => $redirect,
            'scope' => 'identify email',
        ];

        $options = [
            'http' => [
                'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
                'method' => 'POST',
                'content' => http_build_query($data),
            ],
        ];

        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);

        $result = json_decode($result);

        $access_token = $result->access_token;
        $token_type = $result->token_type;

        $url = 'https://discord.com/api/users/@me';

        $options = [
            'http' => [
                'header' => "Authorization: {$token_type} {$access_token}\r\n",
                'method' => 'GET',
            ],
        ];

        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);

        $result = json_decode($result);

        $id = $result->id;
        $username = $result->username;

        $user = $request->user();
        $user->discord_username = $username;
        $user->discord_id = $id;
        $user->save();

        return redirect()->route('account');
    }

    /**
     * Redirect to Discord OAuth2
     */
    public function redirect(Request $request)
    {
        $config = discordAuthConfig::getAuthConfig();

        $client_id = $config->client_id;
        $redirect = route('auth.discord.callback');

        $url = 'https://discord.com/api/oauth2/authorize';

        $data = [
            'client_id' => $client_id,
            'redirect_uri' => $redirect,
            'response_type' => 'code',
            'scope' => 'identify email',
        ];

        $url = $url . '?' . http_build_query($data);

        return redirect()->away($url);
    }

    /**
     * Login with Discord
     */
    public function login(Request $request)
    {
        if (!$request->has('code')) {
            $config = discordAuthConfig::getAuthConfig();

            $client_id = $config->client_id;
            $redirect = route('auth.discord.login');

            $url = 'https://discord.com/api/oauth2/authorize';

            $data = [
                'client_id' => $client_id,
                'redirect_uri' => $redirect,
                'response_type' => 'code',
                'scope' => 'identify email',
            ];

            $url = $url . '?' . http_build_query($data);

            return redirect()->away($url);
        } else {
            $code = $request->input('code');

            $config = discordAuthConfig::getAuthConfig();

            $client_id = $config->client_id;
            $client_secret = $config->client_secret;
            $redirect = route('auth.discord.login');

            $url = 'https://discord.com/api/oauth2/token';

            $data = [
                'client_id' => $client_id,
                'client_secret' => $client_secret,
                'grant_type' => 'authorization_code',
                'code' => $code,
                'redirect_uri' => $redirect,
                'scope' => 'identify email',
            ];

            $options = [
                'http' => [
                    'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
                    'method' => 'POST',
                    'content' => http_build_query($data),
                ],
            ];

            $context = stream_context_create($options);
            $result = file_get_contents($url, false, $context);

            $result = json_decode($result);

            $access_token = $result->access_token;
            $token_type = $result->token_type;

            $url = 'https://discord.com/api/users/@me';

            $options = [
                'http' => [
                    'header' => "Authorization: {$token_type} {$access_token}\r\n",
                    'method' => 'GET',
                ],
            ];

            $context = stream_context_create($options);
            $result = file_get_contents($url, false, $context);

            $result = json_decode($result);

            $id = $result->id;
            $username = $result->username;

            $user = User::where('discord_id', $id)->first();

            if ($user) {
                auth()->login($user, true);
                return redirect()->route('index');
            } else {
                return redirect()->route('auth.login');
            }
        }
    }
}