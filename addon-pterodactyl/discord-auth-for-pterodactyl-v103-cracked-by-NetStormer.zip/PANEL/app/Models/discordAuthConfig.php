<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property string $key
 * @property string $value
 * @property \Carbon\CarbonImmutable $created_at
 * @property \Carbon\CarbonImmutable $updated_at
 */

class discordAuthConfig extends Model
{
    use HasFactory;

    protected $table = 'discord_auth_config';

    protected $fillable = [
        'key',
        'value',
    ];

    protected $casts = [
        'id' => 'integer',
    ];

    public $timestamps = true;

    public static function getAuthConfig()
    {
        $config = self::all();
        $authConfig = [];
        foreach ($config as $key => $value) {
            $authConfig[$value->key] = $value->value;
        }
        $authConfig = (object) $authConfig;
        return $authConfig;
    }
}