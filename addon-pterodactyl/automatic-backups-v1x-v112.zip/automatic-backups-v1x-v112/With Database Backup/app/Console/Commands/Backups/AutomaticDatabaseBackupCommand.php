<?php

namespace Pterodactyl\Console\Commands\Backups;

use Carbon\Carbon;
use Pterodactyl\Models\Server;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Pterodactyl\Repositories\Eloquent\SettingsRepository;
use Pterodactyl\Services\Backups\Databases\CreateDatabaseBackupService;
use Pterodactyl\Services\Backups\Databases\DeleteDatabaseBackupService;

class AutomaticDatabaseBackupCommand extends Command
{
    /**
     * @var string
     */
    protected $signature = 'p:backups:database:auto';

    /**
     * @var string
     */
    protected $description = 'Manage auto database backups.';

    /**
     * @var SettingsRepository
     */
    protected $settingsRepository;

    /**
     * @var CreateDatabaseBackupService
     */
    protected $createDatabaseBackupService;

    /**
     * @param SettingsRepository $settingsRepository
     * @param CreateDatabaseBackupService $createDatabaseBackupService
     */
    public function __construct(SettingsRepository $settingsRepository, CreateDatabaseBackupService $createDatabaseBackupService)
    {
        parent::__construct();

        $this->settingsRepository = $settingsRepository;
        $this->createDatabaseBackupService = $createDatabaseBackupService;
    }

    /**
     *
     */
    public function handle()
    {
        $excludedHosts = json_decode($this->settingsRepository->get('backup::database::auto::excluded', '{}'), true);

        foreach (Server::query()->whereNull('status')->get() as $server) {
            foreach ($server->databases()->whereNotIn('database_host_id', $excludedHosts)->get() as $database) {
                $database->automatic_backup = true;

                if (!$this->createDatabaseBackupService->startBackup(
                    $database,
                    str_replace('[DATE]', Carbon::now()->format('Y-m-d'), $this->settingsRepository->get('backup::database::auto::name', 'Automatic Database Backup [DATE]')),
                    config('backups.database', 'panel')
                )['created']) {
                    $this->line(sprintf('Failed to start the backup creation for %s', $database->id));
                }
            }

            // Delete old automatic backups
            $daysToStore = $this->settingsRepository->get('backup::database::auto::days', 0);
            $weeksToStore = $this->settingsRepository->get('backup::database::auto::weeks', 0);
            $monthsToStore = $this->settingsRepository->get('backup::database::auto::months', 0);
            $databaseBackups = DB::table('database_backups')->where('is_automatic', '=', 1)->orderBy('created_at', 'DESC')->get();

            foreach ($databaseBackups as $key => $backup) {
                $daysInDiff = Carbon::parse(date('Y-m-d', strtotime($backup->created_at)))->diffInDays(Carbon::now());

                // Check every day store
                if ($daysInDiff < $daysToStore) {
                    continue;
                }

                // Check week store
                if ($daysInDiff < $daysToStore + ($weeksToStore * 7)) {
                    if (self::hasEarlierBackupForWeek($databaseBackups, $key)) {
                        DeleteDatabaseBackupService::delete($backup->id);
                    }

                    continue;
                }

                // Check month store
                if ($daysInDiff < Carbon::now()->subDays($daysToStore + ($weeksToStore * 7))->subMonths($monthsToStore)->diffInDays(Carbon::now())) {
                    if (self::hasEarlierBackupForMonth($databaseBackups, $key)) {
                        DeleteDatabaseBackupService::delete($backup->id);
                    }

                    continue;
                }

                // Delete in every other case
                DeleteDatabaseBackupService::delete($backup->id);
            }
        }
    }

    /**
     * @param $backups
     * @param $key
     * @return bool
     */
    private static function hasEarlierBackupForWeek($backups, $key)
    {
        if (date('N', strtotime($backups[$key]->created_at)) == 1) {
            return false;
        }

        if (!isset($backups[$key + 1]->created_at)) {
            return false;
        }

        if (
            date('N', strtotime($backups[$key + 1]->created_at)) < date('N', strtotime($backups[$key]->created_at)) &&
            date('Y-W', strtotime($backups[$key + 1]->created_at)) == date('Y-W', strtotime($backups[$key]->created_at))
        ) {
            return true;
        }

        return false;
    }

    /**
     * @param $backups
     * @param $key
     * @return bool
     */
    private static function hasEarlierBackupForMonth($backups, $key)
    {
        if (date('j', strtotime($backups[$key]->created_at)) == 1) {
            return false;
        }

        if (!isset($backups[$key + 1]->created_at)) {
            return false;
        }

        if (
            date('j', strtotime($backups[$key + 1]->created_at)) < date('j', strtotime($backups[$key]->created_at)) &&
            date('Y-n', strtotime($backups[$key + 1]->created_at)) == date('Y-n', strtotime($backups[$key]->created_at))
        ) {
            return true;
        }

        return false;
    }
}
