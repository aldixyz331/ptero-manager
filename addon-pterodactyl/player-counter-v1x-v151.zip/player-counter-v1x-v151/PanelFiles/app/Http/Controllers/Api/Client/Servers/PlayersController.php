<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use GameQ\GameQ;
use xPaw\MinecraftPing;
use xPaw\MinecraftQuery;
use Pterodactyl\Models\Server;
use xPaw\MinecraftPingException;
use xPaw\SourceQuery\SourceQuery;
use xPaw\MinecraftQueryException;
use Illuminate\Support\Facades\DB;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Http\Requests\Api\Client\Servers\GetServerRequest;

class PlayersController extends ClientApiController
{
    /**
     * @param GetServerRequest $request
     * @param Server $server
     * @return array
     */
    public function index(GetServerRequest $request, Server $server)
    {
        $counters = DB::table('player_counter')->get();
        foreach ($counters as $counterItem) {
            if (in_array($server->egg_id, explode(',', $counterItem->egg_ids))) {
                $counter = $counterItem;
            }
        }

        $max_players = 0;
        $online_players = 0;
        $players = [];

        if (isset($counter)) {
            // Fetch IP and port
            $ip = $server->allocation->ip;
            $port = $server->allocation->port;

            // Fetch players with different functions
            try {
                [$max_players, $online_players, $players] = match ($counter->game) {
                    'minecraft' => $this->getMinecraftPlayers($ip, $port),
                    'minecraftpe' => $this->getBedrockPlayers($ip, $port),
                    'csgo', 'cs16', 'css', 'eco', 'hypercharge', 'killingfloor', 'project_zomboid', 'vrising', 'unturned', 'theisle', 'arma3' => $this->getSourcePlayers($ip, $port, $counter->game),
                    default => $this->getGameQPlayers($ip, $port, $counter->game),
                };
            } catch (\Exception $e) {
                unset($counter);
            }
        }

        // If max players is zero, unset the counter because failed to fetch
        if ($max_players == 0) {
            unset($counter);
        }

        return [
            'success' => true,
            'data' => [
                'show' => isset($counter) ? 1 : 0,
                'maxPlayers' => $max_players,
                'onlinePlayers' => $online_players,
                'players' => $players,
            ],
        ];
    }

    /**
     * @param $ip
     * @param $port
     * @return array
     * @throws \Exception
     */
    private function getMinecraftPlayers($ip, $port)
    {
        $query = null;

        try {
            // Firstly try with ping for minimum version 1.7
            $query = new MinecraftPing($ip, $port, 2, true);
            $info = $query->Query();

            if ($info !== false) {
                // Fetch players if correct
                $max_players = $info['players']['max'] ?? 0;
                $online_players = $info['players']['online'] ?? 0;
            } else {
                // Close the old try and connect
                $query->Close();
                $query->Connect();

                // Try with the older query methods before version 1.7
                $info = $query->QueryOldPre17();
                $max_players = $info['MaxPlayers'] ?? 0;
                $online_players = $info['Players'] ?? 0;
            }
        } catch (MinecraftPingException $e) {
            // Just continue, failed to fetch
            throw new \Exception($e->getMessage());
        } finally {
            // Close the connection if it is still opened
            $query?->Close();
        }

        return [$max_players, $online_players, []];
    }

    /**
     * @param $ip
     * @param $port
     * @return array
     * @throws \Exception
     */
    private function getBedrockPlayers($ip, $port)
    {
        try {
            // For bedrock (mcpe), we need to use Minecraft Query class
            $query = new MinecraftQuery();

            // Handle query action
            $query->ConnectBedrock($ip, $port);

            // Fetch info
            $info = $query->GetInfo();
            $max_players = $info['MaxPlayers'] ?? 0;
            $online_players = $info['Players'] ?? 0;

            return [$max_players, $online_players, []];
        } catch (MinecraftQueryException $e) {
            // Just continue, failed to fetch
            throw new \Exception($e->getMessage());
        }
    }

    /**
     * @param $ip
     * @param $port
     * @param $game
     * @return array
     * @throws \Exception
     */
    private function getSourcePlayers($ip, $port, $game)
    {
        $query = new SourceQuery();

        // Increase port if needed
        if (in_array($game, ['unturned', 'theisle', 'arma3'])) {
            $port += 1;
        }

        try {
            // Try to connect
            $query->Connect($ip, $port, 1, SourceQuery::SOURCE);
            $results = $query->GetInfo();

            // Fetch result
            $max_players = $results['MaxPlayers'] ?? 0;
            $online_players = $results['Players'] ?? 0;
        } catch (\Exception $e) {
            // Just continue, failed to fetch
            throw new \Exception($e->getMessage());
        } finally {
            // Close if connection is still alive
            $query->Disconnect();
        }

        return [$max_players, $online_players, []];
    }

    /**
     * @param $ip
     * @param $port
     * @param $game
     * @return array
     * @throws \Exception
     */
    public function getGameQPlayers($ip, $port, $game)
    {
        // Create class
        $options = [];
        $players = [];
        $GameQ = new GameQ();

        // Append extra port if needed
        if (in_array($game, ['bf3', 'sevendaystodie', 'conanexiles', 'rust'])) {
            $options['query_port'] = $port + 1;
        }

        // Add server
        $GameQ->addServer([
            'type' => $game,
            'host' => sprintf('%s:%s', $ip, $port),
            'options' => $options,
        ]);

        // Process the request
        $results = array_values($GameQ->process());

        // Fetch player counts
        $max_players = $results[0]['gq_maxplayers'] ?? 0;
        $online_players = $results[0]['gq_numplayers'] ?? 0;

        if ($game == 'gta5m') {
            // Fetch player list for FiveM
            $players = PlayersController::getFiveMPlayerList(sprintf('%s:%s', $ip, $port));
        } else {
            // Fetch players from GameQ
            if (isset($results[$ip . ':' . $port]['players'])) {
                foreach ($results[$ip . ':' . $port]['players'] as $player) {
                    $players[] = $player['gq_name'];
                }
            }
        }

        return [$max_players, $online_players, $players];
    }

    /**
     * @param $connection
     * @return array
     */
    private static function getFiveMPlayerList($connection)
    {
        $json = @file_get_contents(sprintf('http://%s/players.json', $connection));
        if ($json) {
            $players = [];
            $data = json_decode($json);

            foreach ($data as $player) {
                $players[] = $player->name;
            }

            return $players;
        }

        return [];
    }
}
