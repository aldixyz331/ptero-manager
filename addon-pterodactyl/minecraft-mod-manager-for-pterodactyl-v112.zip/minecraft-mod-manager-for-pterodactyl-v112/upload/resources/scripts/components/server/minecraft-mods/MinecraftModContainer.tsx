import http from '@/api/http';
import { getPaginationSet, PaginatedResult } from '@/api/http';
import Input from '@/components/elements/Input';
import Pagination from '@/components/elements/Pagination';
import Label from '@/components/elements/Label';
import Select from '@/components/elements/Select';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import Spinner from '@/components/elements/Spinner';
import useFlash from '@/plugins/useFlash';
import { ServerContext } from '@/state/server';
import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router';
import useSWR from 'swr';
import tw from 'twin.macro';
import MinecraftModRow from './MinecraftModRow';
import getMinecraftSoftware from '@/api/swr/getMinecraftSoftware';
import { NavLink } from 'react-router-dom';
import { Button } from '@/components/elements/button';

export type MinecraftModProvider = 'curseforge' | 'modrinth';

export interface MinecraftMod {
    id: string;
    name: string;
    short_description: string;
    url: string;
    icon_url: string | null;
    external_url: string | null;
}

type MinecraftModResponse = PaginatedResult<MinecraftMod>;

const modLoaders = [
    {
        id: 'forge',
        name: 'Forge',
    },
    {
        id: 'neoforge',
        name: 'NeoForge',
    },
    {
        id: 'fabric',
        name: 'Fabric',
    },
    {
        id: 'liteloader',
        name: 'LiteLoader',
    },
    {
        id: 'quilt',
        name: 'Quilt',
    },
    {
        id: 'modloader',
        name: "Risugami's ModLoader",
    },
    {
        id: 'rift',
        name: 'Rift',
    },
];

export default () => {
    const { search } = useLocation();
    const params = new URLSearchParams(search);
    const defaultProvider = (params.get('provider') as MinecraftModProvider) || 'modrinth';
    const defaultQuery = params.get('query') || '';
    const defaultPageSize = params.get('pageSize') || 50;
    const defaultModLoader = params.get('modLoader') || '';
    const defaultMinecraftVersion = params.get('minecraftVersion') || '';
    const defaultPage = Number(params.get('page') || 1);

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const shortUuid = ServerContext.useStoreState((state) => state.server.data!.id);
    const [modProvider, setModProvider] = useState<MinecraftModProvider>(defaultProvider);
    const [searchQuery, setSearchQuery] = useState<string>(defaultQuery);
    const [pageSize, setPageSize] = useState(defaultPageSize);
    const [modLoader, setModLoader] = useState(defaultModLoader);
    const [minecraftVersion, setMinecraftVersion] = useState(defaultMinecraftVersion);
    const [minecraftVersions, setMinecraftVersions] = useState<string[]>([]);
    const [page, setPage] = useState(!isNaN(defaultPage) && defaultPage > 0 ? defaultPage : 1);

    const { clearFlashes, clearAndAddHttpError } = useFlash();

    const { data: mods, error } = useSWR<MinecraftModResponse>(
        ['minecraft-mods', modProvider, searchQuery, pageSize, page, modLoader, minecraftVersion],
        async () => {
            const { data } = await http.get(`/api/client/servers/${uuid}/minecraft-mods`, {
                params: {
                    provider: modProvider,
                    search_query: searchQuery,
                    page_size: pageSize,
                    page: page,
                    mod_loader: modLoader,
                    minecraft_version: minecraftVersion,
                },
            });
            return {
                items: data.data || [],
                pagination: getPaginationSet(data.meta.pagination),
            };
        }
    );

    useEffect(() => {
        http.get('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json', {
            // for CORS
            withCredentials: false,
            transformRequest: [
                function (data, headers) {
                    if (headers) {
                        delete headers['X-Requested-With'];
                    }
                    return data;
                },
            ],
        }).then(({ data }) =>
            setMinecraftVersions(
                data.versions
                    .filter((v: { id: string; type: string }) => v.type === 'release')
                    .map((v: { id: string; type: string }) => v.id)
            )
        );
    }, []);

    useEffect(() => {
        // Don't use react-router to handle changing this part of the URL, otherwise it
        // triggers a needless re-render. We just want to track this in the URL incase the
        // user refreshes the page.
        const params = new URLSearchParams();
        if (modProvider !== 'modrinth') {
            params.set('provider', modProvider);
        }
        if (searchQuery.length > 0) {
            params.set('query', searchQuery);
        }
        if (modLoader !== '') {
            params.set('modLoader', modLoader);
        }
        if (pageSize !== 50) {
            params.set('pageSize', pageSize.toString());
        }
        if (minecraftVersion !== '') {
            params.set('minecraftVersion', minecraftVersion);
        }
        if (page > 1) {
            params.set('page', page.toString());
        }

        window.history.replaceState(
            null,
            document.title,
            `/server/${shortUuid}/minecraft-mods${params.toString().length > 0 ? '?' + params.toString() : ''}`
        );
    }, [modProvider, searchQuery, pageSize, page, minecraftVersion, modLoader]);

    useEffect(() => {
        if (!mods) return;
        if (mods.pagination.currentPage > 1 && !mods.items.length) {
            setPage(1);
        }
    }, [mods?.pagination.currentPage]);

    useEffect(() => {
        if (!error) {
            clearFlashes('minecraft-mods');
            return;
        }
        clearAndAddHttpError({ error, key: 'minecraft-mods' });
    }, [error]);

    const { data: minecraftBuildInfo } = getMinecraftSoftware();

    // Set the mod loader filter from detected software if none
    // is currently selected.
    useEffect(() => {
        if (
            minecraftBuildInfo?.buildType &&
            minecraftBuildInfo.buildType !== 'UNKNOWN' &&
            modLoaders.find((a) => a.id === minecraftBuildInfo.buildType.toLowerCase()) &&
            modLoader === ''
        ) {
            setModLoader(minecraftBuildInfo.buildType.toLowerCase());
            setMinecraftVersion(minecraftBuildInfo.versionName);
        }
    }, [minecraftBuildInfo]);

    return (
        <ServerContentBlock title={'Minecraft Mods'} showFlashKey='minecraft-mods'>
            <div css={tw`flex flex-wrap items-end gap-4 mt-3`}>
                <div css={tw`min-w-[112px]`}>
                    <Label htmlFor='mod_provider'>Provider</Label>
                    <Select
                        name='mod_provider'
                        value={modProvider}
                        onChange={(event) => setModProvider(event.target.value as MinecraftModProvider)}
                    >
                        <option value='curseforge'>CurseForge</option>
                        <option value='modrinth'>Modrinth</option>
                    </Select>
                </div>
                <div>
                    <Label htmlFor={'page_size'}>Page size</Label>
                    <Select
                        name='page_size'
                        value={pageSize}
                        onChange={(event) => {
                            setPageSize(Number(event.target.value));
                        }}
                    >
                        <option value='10'>10</option>
                        <option value='25'>25</option>
                        <option value='50'>50</option>
                    </Select>
                </div>
                {modProvider === 'modrinth' && (
                    <div>
                        <Label htmlFor={'mod_loader'}>Mod loader</Label>
                        <Select
                            name='mod_loader'
                            value={modLoader}
                            onChange={(event) => {
                                setModLoader(event.target.value);
                            }}
                        >
                            <option value=''>All</option>
                            {modLoaders.map((loader) => (
                                <option key={loader.id} value={loader.id}>
                                    {loader.name}
                                </option>
                            ))}
                        </Select>
                    </div>
                )}
                {(modProvider === 'modrinth' || modProvider === 'curseforge') && (
                    <div>
                        <Label htmlFor={'minecraft_version'}>Minecraft version</Label>
                        <Select
                            name='minecraft_version'
                            value={minecraftVersion}
                            onChange={(event) => {
                                setMinecraftVersion(event.target.value);
                            }}
                        >
                            <option value=''>All</option>
                            {minecraftVersions.map((ver) => (
                                <option key={ver} value={ver}>
                                    {ver}
                                </option>
                            ))}
                        </Select>
                    </div>
                )}
                <div css={tw`w-full md:w-auto md:flex-1`}>
                    <Label htmlFor='search_query'>Search query</Label>
                    <Input
                        type='text'
                        name='search_query'
                        value={searchQuery}
                        onChange={(event) => {
                            setSearchQuery(event.target.value);
                        }}
                    />
                </div>

                <NavLink to={`/server/${shortUuid}/minecraft-mods/installed`}>
                    <Button className='h-12'>Installed Mods</Button>
                </NavLink>
            </div>
            <div css={tw`mt-3`}>
                {!error && mods ? (
                    <Pagination data={mods} onPageSelect={setPage}>
                        {({ items }) =>
                            items.length > 0 ? (
                                <div className='grid lg:grid-cols-3 gap-2 '>
                                    {items.map((mod) => (
                                        <MinecraftModRow
                                            key={`${page}-${mod.id}`}
                                            provider={modProvider}
                                            modLoader={modLoader}
                                            minecraftVersion={minecraftVersion}
                                            mod={mod}
                                        />
                                    ))}
                                </div>
                            ) : (
                                <p css={tw`text-center text-sm text-neutral-300`}>
                                    No &quot;Minecraft: Java Edition&quot; mods have been found for your query.
                                </p>
                            )
                        }
                    </Pagination>
                ) : (
                    <Spinner centered size='base' />
                )}
            </div>
        </ServerContentBlock>
    );
};
