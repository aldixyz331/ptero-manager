import React, { useState } from 'react';
import GreyRowBox from '@/components/elements/GreyRowBox';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowAltCircleUp, faTrash } from '@fortawesome/free-solid-svg-icons';
import deleteFiles from '@/api/server/files/deleteFiles';
import { ServerContext } from '@/state/server';
import { Dialog } from '@/components/elements/dialog';
import Code from '@/components/elements/Code';
import { installMod } from './MinecraftModRow';
import { InstalledMinecraftProject } from '@/api/definitions/minecraftProject';

export default ({
    mod,
    mutate,
}: {
    mod: InstalledMinecraftProject;
    mutate: (
        data?:
            | InstalledMinecraftProject[]
            | Promise<InstalledMinecraftProject[]>
            | ((
                  currentValue: InstalledMinecraftProject[]
              ) => Promise<InstalledMinecraftProject[]> | InstalledMinecraftProject[])
            | undefined,
        shouldRevalidate?: boolean
    ) => void;
}) => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const [updateDialogOpen, setUpdateDialogOpen] = useState(false);
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

    const remove = () => {
        setDeleteDialogOpen(false);
        deleteFiles(uuid, '/', [mod.path]);
        mutate((data) => {
            return data.filter((m) => m.path !== mod.path);
        });
    };

    const update = async () => {
        setUpdateDialogOpen(false);
        if (mod.update && mod.provider && mod.project_id && mod.update.id) {
            await deleteFiles(uuid, '/', [mod.path]);
            await installMod(uuid, mod.provider, mod.project_id, mod.update.id);
            mutate((data) => {
                return data.map((m) => {
                    if (m.path !== mod.path || !mod.update) return m;
                    return { ...m, version_name: mod.update.name, id: mod.update.id, update: null };
                });
            }, false);
        }
    };

    return (
        <>
            <Dialog.Confirm
                title={`Update ${mod.project_name ?? mod.path}`}
                confirm={'Update Mod'}
                open={updateDialogOpen}
                onClose={() => {
                    setUpdateDialogOpen(false);
                }}
                onConfirmed={() => update()}
            >
                <p>The following procedure will take place:</p>
                <ol className='list-decimal list-inside'>
                    <li>
                        Delete <Code>{mod.path}</Code>
                    </li>
                    <li>
                        Install &quot;{mod.project_name}&quot; with version <Code>{mod.update?.name ?? ''}</Code> from{' '}
                        <Code>{mod.provider ?? ''}</Code> to <Code>mods/</Code>.
                    </li>
                </ol>
            </Dialog.Confirm>
            <Dialog.Confirm
                title={`Remove ${mod.project_name ?? mod.path}`}
                confirm={'Remove Mod'}
                open={deleteDialogOpen}
                onClose={() => {
                    setDeleteDialogOpen(false);
                }}
                onConfirmed={() => remove()}
            >
                <p>
                    <Code>{mod.path}</Code> will be deleted.
                </p>
            </Dialog.Confirm>
            <GreyRowBox>
                <div className='flex flex-col w-full'>
                    <div className='flex flex-row items-center'>
                        {mod.icon_url ? (
                            <img className='h-8 w-8' src={mod.icon_url} />
                        ) : (
                            <svg
                                className='h-8 w-8'
                                xmlSpace='preserve'
                                fillRule='evenodd'
                                strokeLinecap='round'
                                strokeLinejoin='round'
                                strokeMiterlimit='1.5'
                                clipRule='evenodd'
                                viewBox='0 0 104 104'
                                aria-hidden='true'
                            >
                                <path fill='none' d='M0 0h103.4v103.4H0z' />
                                <path
                                    fill='none'
                                    stroke='#9a9a9a'
                                    strokeWidth='5'
                                    d='M51.7 92.5V51.7L16.4 31.3l35.3 20.4L87 31.3 51.7 11 16.4 31.3v40.8l35.3 20.4L87 72V31.3L51.7 11'
                                />
                            </svg>
                        )}
                        <div className='flex flex-col ml-3'>
                            <span>{mod.project_name ?? mod.path}</span>
                            <span className='text-neutral-300 text-sm break-all'>{mod.version_name}</span>
                        </div>
                        <div className='shrink-0 ml-auto'>
                            {mod.update && (
                                <button
                                    title='Update'
                                    className='p-2 text-sm text-neutral-400 hover:text-blue-400 transition-colors duration-150'
                                    onClick={() => {
                                        setUpdateDialogOpen(true);
                                    }}
                                >
                                    <FontAwesomeIcon icon={faArrowAltCircleUp} />
                                </button>
                            )}
                            <button
                                title='Remove'
                                className='ml-3 p-2 text-sm text-neutral-400 hover:text-red-400 transition-colors duration-150'
                                onClick={() => {
                                    setDeleteDialogOpen(true);
                                }}
                            >
                                <FontAwesomeIcon icon={faTrash} />
                            </button>
                        </div>
                    </div>
                </div>
            </GreyRowBox>
        </>
    );
};
