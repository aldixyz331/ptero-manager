import http from '@/api/http';
import { Dialog } from '@/components/elements/dialog';
import Select from '@/components/elements/Select';
import Label from '@/components/elements/Label';
import GreyRowBox from '@/components/elements/GreyRowBox';
import useFlash from '@/plugins/useFlash';
import { ServerContext } from '@/state/server';
import { faExternalLinkAlt, faDownload } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React, { useEffect, useState } from 'react';
import tw from 'twin.macro';
import { MinecraftMod, MinecraftModProvider } from './MinecraftModContainer';

interface Props {
    provider: MinecraftModProvider;
    mod: MinecraftMod;
    modLoader: string;
    minecraftVersion: string;
    className?: string;
}

interface MinecraftPluginVersion {
    id: string;
    name: string;
    game_versions: string[];
    download_url: string;
}

export const installMod = (uuid: string, provider: string, modId: string, versionId: string) => {
    return http.post(`/api/client/servers/${uuid}/minecraft-mods/install`, {
        provider: provider,
        modId: modId,
        versionId: versionId,
    });
};

export default ({ provider, mod, modLoader, minecraftVersion, className }: Props) => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { clearFlashes, addFlash, clearAndAddHttpError } = useFlash();
    const [installDialogVisible, setInstallDialogVisible] = useState<boolean>(false);
    const [versions, setVersions] = useState<MinecraftPluginVersion[]>([]);
    const [selectedVersion, setSelectedVersion] = useState<string | null>(null);

    const install = () => {
        if (selectedVersion) {
            installMod(uuid, provider, mod.id, selectedVersion)
                .then(() => {
                    clearFlashes();
                    addFlash({
                        key: 'minecraft-mods',
                        message: `Mod "${mod.name}" successfully installed in /home/container/mods.`,
                        type: 'success',
                    });
                })
                .catch((error) => {
                    clearAndAddHttpError({ error, key: 'minecraft-mods' });
                });
        }

        setInstallDialogVisible(false);
    };

    useEffect(() => {
        if (installDialogVisible && !versions.length) {
            http.get(`/api/client/servers/${uuid}/minecraft-mods/versions`, {
                params: {
                    provider: provider,
                    modId: mod.id,
                    modLoader: modLoader,
                    minecraftVersion: minecraftVersion,
                },
            })
                .then(({ data }) => {
                    setVersions(data);
                    setSelectedVersion(data[0]?.id);
                })
                .catch((error) => {
                    clearAndAddHttpError({ error, key: 'minecraft-mods' });
                    setInstallDialogVisible(false);
                });
        }
    }, [installDialogVisible]);

    return (
        <>
            <Dialog.Confirm
                title={'Install mod'}
                confirm={'Install mod'}
                open={installDialogVisible}
                onClose={() => setInstallDialogVisible(false)}
                onConfirmed={install}
            >
                <p>
                    You requested the installation of the mod &quot;{mod.name}&quot; from the {provider} provider.
                    Please select the desired mod version below.
                </p>
                <Label className={'mt-3'} htmlFor='mod_version_id'>
                    Mod version
                </Label>
                <Select
                    name='mod_version_id'
                    onChange={(event) => {
                        setSelectedVersion(event.target.value);
                    }}
                >
                    {versions.map((version) => (
                        <option key={version.id} value={version.id}>
                            {version.name}
                        </option>
                    ))}
                </Select>
            </Dialog.Confirm>
            <GreyRowBox className={className} css={tw`items-center`}>
                <img
                    src={mod.icon_url ?? 'https://placehold.co/32'}
                    css={tw`rounded-md w-8 h-8 sm:w-12 sm:h-12 object-contain flex items-center justify-center`}
                />
                <div css={tw`ml-3 flex flex-col`}>
                    {mod.url ? (
                        <a href={mod.url} target='_blank' rel='noreferrer' css={tw`hover:text-gray-400`}>
                            {mod.name} <FontAwesomeIcon icon={faExternalLinkAlt} css={tw`ml-1 h-3 w-3`} />
                        </a>
                    ) : (
                        <p>{mod.name}</p>
                    )}
                    <p css={tw`text-neutral-300 line-clamp-2`}>{mod.short_description}</p>
                </div>
                {mod.external_url ? (
                    <a
                        title='Go to external URL'
                        target='_blank'
                        rel='noreferrer'
                        css={tw`ml-auto p-2 text-sm text-neutral-400 hover:text-green-400 transition-colors duration-150`}
                        href={mod.external_url}
                    >
                        <FontAwesomeIcon icon={faExternalLinkAlt} />
                    </a>
                ) : (
                    <button
                        title='Install'
                        css={tw`ml-auto p-2 text-sm text-neutral-400 hover:text-green-400 transition-colors duration-150`}
                        onClick={() => setInstallDialogVisible(true)}
                    >
                        <FontAwesomeIcon icon={faDownload} />
                    </button>
                )}
            </GreyRowBox>
        </>
    );
};
