<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Models\Server;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Models\Permission;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;
use Pterodactyl\Services\Minecraft\Mods\CurseForgeModService;
use Pterodactyl\Services\Minecraft\Mods\ModrinthModService;
use Pterodactyl\Services\Minecraft\Mods\MinecraftModProvider;
use Pterodactyl\Services\Minecraft\MinecraftSoftwareService;

class MinecraftModController extends ClientApiController
{
    /**
     * MinecraftModController constructor.
     */
    public function __construct(private DaemonFileRepository $daemonFileRepository)
    {
        parent::__construct();
    }

    /**
     * Returns searched Minecraft mods.
     */
    public function index(Request $request, Server $server): array
    {
        if (!$request->user()->can(Permission::ACTION_FILE_READ, $server)) {
            throw new AuthorizationException();
        }
        $validated = $request->validate([
            'provider' => ['required', Rule::enum(MinecraftModProvider::class)],
            'page' => 'required|numeric|integer|min:1',
            'page_size' => 'required|numeric|integer|max:50', // CurseForge page size max is 50
            'search_query' => 'nullable|string',
            'minecraft_version' => 'nullable|string',
            'mod_loader' => 'nullable|string',
        ]);

        $provider = MinecraftModProvider::from($validated['provider']);
        $page = (int) $validated['page'];
        $pageSize = (int) $validated['page_size'];
        $searchQuery = $validated['search_query'] ?? '';
        $minecraftVersion = $validated['minecraft_version'] ?? null;
        $modLoader = $validated['mod_loader'] ?? null;

        $service = $this->getModService($provider);

        $data = $service->search(compact('searchQuery', 'pageSize', 'page', 'minecraftVersion', 'modLoader'));

        $mods = $data['data'];

        return [
            'object' => 'list',
            'data' => $mods,
            'meta' => [
                'pagination' => [
                    'total' => $data['total'],
                    'count' => count($mods),
                    'per_page' => $pageSize,
                    'current_page' => $page,
                    'total_pages' => ceil($data['total'] / $pageSize),
                    'links' => [],
                ],
            ],
        ];
    }

    /**
     * Returns a mod's installable versions.
     */
    public function versions(Request $request, Server $server): array
    {
        if (!$request->user()->can(Permission::ACTION_FILE_READ, $server)) {
            throw new AuthorizationException();
        }
        $validated = $request->validate([
            'provider' => ['required', Rule::enum(MinecraftModProvider::class)],
            'modId' => 'required|string',
            'modLoader' => 'nullable|string',
            'minecraftVersion' => 'nullable|string',
        ]);

        $provider = MinecraftModProvider::from($validated['provider']);
        $modId = $validated['modId'];
        $modLoader = $validated['modLoader'] ?? null;
        $minecraftVersion = $validated['minecraftVersion'] ?? null;

        $service = $this->getModService($provider);

        $data = $service->versions($modId, $modLoader, $minecraftVersion);

        return $data;
    }


    protected function getModService(MinecraftModProvider $provider) {
        $class = match ($provider) {
            MinecraftModProvider::CurseForge => CurseForgeModService::class,
            MinecraftModProvider::Modrinth => ModrinthModService::class,
        };
        return app($class);
    }

    /**
     * Returns normalized mod versions from `mods/` hashes.
     *
     * @return array{identified: array<array{id: string, project_id: string, name: string, provider: string}>}
     */
    public function getInstalledModsVersions(Server $server, MinecraftSoftwareService $minecraftSoftwareService): array
    {
        return $minecraftSoftwareService->setServer($server)->getInstalledProjectsVersions('mods');
    }

    /**
     * Install a remote mod.
     */
    public function installMod(Request $request, Server $server)
    {
        if (!$request->user()->can(Permission::ACTION_FILE_CREATE, $server)) {
            throw new AuthorizationException();
        }

        $validated = $request->validate([
            'provider' => ['required', Rule::enum(MinecraftModProvider::class)],
            'modId' => 'required|string',
            'versionId' => 'required|string',
        ]);
        $provider = MinecraftModProvider::from($validated['provider']);
        $modId = $validated['modId'];
        $versionId = $validated['versionId'];

        $service = $this->getModService($provider);
        $downloadUrl = $service->getDownloadUrl($modId, $versionId);

        try {
            $this->daemonFileRepository->setServer($server)->pull(
                $downloadUrl,
                '/mods',
                ['use_header' => true, 'foreground' => true]
            );
        } catch (\Exception $e) {
            throw new DisplayException(
                'Looks like we couldn\'t download this mod automatically. ' .
                'You should still be able to download it in your browser at ' . $downloadUrl
            );
        }

        return response()->noContent();
    }
}
