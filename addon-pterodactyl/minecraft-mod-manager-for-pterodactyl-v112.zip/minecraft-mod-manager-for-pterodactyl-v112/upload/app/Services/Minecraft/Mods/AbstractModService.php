<?php

namespace Pterodactyl\Services\Minecraft\Mods;

use Pterodactyl\Models\Server;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;

abstract class AbstractModService
{
    protected string $userAgent;

    public function __construct(protected DaemonFileRepository $daemonFileRepository)
    {
        $this->userAgent = config('app.name') . '/' . config('app.version') . ' (' . url('/') . ')';
    }

    abstract public function search(array $filters): array;

    abstract public function versions(string $modId, ?string $modLoader = null, ?string $minecraftVersion = null): array;

    abstract public function getDownloadUrl(string $modId, string $versionId): string;

    /**
     * Returns normalized mod versions from $paths hashes.
     *
     * @param  string[]  $paths
     */
    abstract public function getModsVersions(Server $server, array $paths, ?array $serverBuildInfo = null): array;
}
