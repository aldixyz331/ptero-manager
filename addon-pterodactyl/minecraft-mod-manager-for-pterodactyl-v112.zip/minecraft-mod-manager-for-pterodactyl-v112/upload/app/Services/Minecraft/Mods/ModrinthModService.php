<?php

namespace Pterodactyl\Services\Minecraft\Mods;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\BadResponseException;
use GuzzleHttp\Exception\TransferException;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\Cache;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;

class ModrinthModService extends AbstractModService
{
    protected Client $client;

    public function __construct(protected DaemonFileRepository $daemonFileRepository)
    {
        parent::__construct($daemonFileRepository);

        $this->client = new Client([
            'headers' => [
                'User-Agent' => $this->userAgent,
            ],
            'base_uri' => 'https://api.modrinth.com/v2/',
        ]);
    }

    public function search(array $filters): array
    {
        $query = $filters['searchQuery'];
        $pageSize = $filters['pageSize'];
        $page = $filters['page'];
        $minecraftVersion = $filters['minecraftVersion'];
        $modLoader = $filters['modLoader'];
        $facets = '["project_type:mod"],["server_side!=unsupported"]';

        if (!empty($minecraftVersion)) {
            $facets .= ',["versions:' . $minecraftVersion . '"]';
        }

        if (! empty($modLoader)) {
            $facets .= ',["categories:'.$modLoader.'"]';
        }

        try {
            $response = json_decode($this->client->get('search', [
                'query' => [
                    'offset' => ($page - 1) * $pageSize,
                    'facets' => '[ ' . $facets . ' ]',
                    'limit' => $pageSize,
                    'query' => $query,
                    'index' => 'relevance',
                ],
            ])->getBody(), true);
        } catch (TransferException $e) {
            if ($e instanceof BadResponseException) {
                logger()->error('Received bad response when fetching Modrinth mods.', ['response' => \GuzzleHttp\Psr7\Message::toString($e->getResponse())]);
            }

            return [
                'data' => [],
                'total' => 0,
            ];
        }

        $mods = [];

        foreach ($response['hits'] as $modrinthMod) {
            $mods[] = [
                'id' => $modrinthMod['project_id'],
                'name' => $modrinthMod['title'],
                'short_description' => $modrinthMod['description'],
                'url' => 'https://modrinth.com/mod/' . $modrinthMod['slug'],
                'icon_url' => empty($modrinthMod['icon_url']) ? null : $modrinthMod['icon_url'],
            ];
        }

        return [
            'data' => $mods,
            'total' => $response['total_hits'],
        ];
    }


    /**
     * Returns normalized Modrinth mod versions from SHA512 $hashes or `mods/` SHA512 hashes
     * as well as of the last version if not up-to-date.
=     */
    public function getModsVersions(Server $server, array $paths, ?array $serverBuildInfo = null): array
    {
        $algorithm = 'sha512';
        $hashes = $this->daemonFileRepository->setServer($server)->getFingerprints($paths, $algorithm);
        $hashesToPaths = array_flip($hashes);

        $versionsResponse = $this->client->post('version_files',
            [
                'json' => [
                    'hashes' => array_values($hashes),
                    'algorithm' => $algorithm,    
                ],
            ]);

        $versions = $versionsResponse->getStatusCode() === 200 ? json_decode($versionsResponse->getBody(), true) : [];

        $normalizedVersions = [];

        foreach ($versions as $hash => $modrinthVersion) {
            $normalizedVersions[$modrinthVersion['project_id']] = [
                'path' => $hashesToPaths[$hash],
                'provider' => 'modrinth',
                'project_id' => $modrinthVersion['project_id'],
                'project_name' => null,
                'version_id' => $modrinthVersion['id'],
                'version_name' => $modrinthVersion['version_number'],
                'icon_url' => null,
            ];
        }

        if ($serverBuildInfo['buildType'] !== 'UNKNOWN') {
            $latestVersionsResponse = $this->client->post('version_files/update',
            [
                'json' => [
                    'hashes' => array_values($hashes),
                    'algorithm' => $algorithm,
                    'loaders' => [strtolower($serverBuildInfo['buildType'])],
                    'game_versions' => [$serverBuildInfo['versionName']],
                ],
            ]);
    
            $latestVersions = $latestVersionsResponse->getStatusCode() === 200 ? json_decode($latestVersionsResponse->getBody(), true) : [];
            foreach ($latestVersions as $hash => $latestVersion) {
                // Seems like Modrinth can return unpublished projects???
                if (!isset($normalizedVersions[$latestVersion['project_id']])) {
                    continue;
                }
                if ($normalizedVersions[$latestVersion['project_id']]['version_id'] !== $latestVersion['id']) {
                    $normalizedVersions[$latestVersion['project_id']]['update']['id'] = $latestVersion['id'];
                    $normalizedVersions[$latestVersion['project_id']]['update']['name'] = $latestVersion['version_number'];    
                }
            }    
        }

        $projectsResponse = $this->client->get('projects',
            [
                'query' => [
                    'ids' => $this->modrinthQueryArray(array_keys($normalizedVersions)),    
                ],
            ]);
        $projects = json_decode($projectsResponse->getBody(), true);
        foreach ($projects as $project) {
            $normalizedVersions[$project['id']]['project_name'] = $project['title'];
            $normalizedVersions[$project['id']]['icon_url'] = $project['icon_url'];
        }

        // Array of file paths for which no mod version could be found.
        $other = [];

        foreach ($hashes as $filePath => $hash) {
            if (! isset($versions[$hash])) {
                $other[] = $filePath;
            }
        }

        return ['identified' => array_values($normalizedVersions), 'other' => $other];
    }

    /**
     * @param  array<string>  $array
     */
    protected static function modrinthQueryArray(array $array): string
    {
        return '['.implode(',', array_map(fn (string $s): string => '"'.$s.'"', $array)).']';
    }

    public function versions(string $modId, ?string $modLoader = null, ?string $minecraftVersion = null): array
    {
        $loaders = empty($modLoader) ? $this->getModLoaders() : [$modLoader];

        try {
            $response = json_decode($this->client->get('project/' . $modId . '/version', [
                'query' => [
                    'loaders' => $this->modrinthQueryArray($loaders),
                    'game_versions' => empty($minecraftVersion) ? null : $this->modrinthQueryArray([$minecraftVersion]),
                ],
            ])->getBody(), true);
        } catch (TransferException $e) {
            if ($e instanceof BadResponseException) {
                logger()->error('Received bad response when fetching Modrinth mod files.', ['response' => \GuzzleHttp\Psr7\Message::toString($e->getResponse())]);
            }
        }

        $versions = [];

        foreach ($response as $version) {
            $versions[] = [
                'id' => $version['id'],
                'name' => $version['name'],
                'game_versions' => $version['game_versions'],
                'download_url' => $version['files'][0]['url'],
            ];
        }

        return $versions;
    }


    public function getDownloadUrl(string $modId, string $versionId): string
    {
        try {
            $response = json_decode($this->client->get('project/' . $modId . '/version/' . $versionId)->getBody(), true);
        } catch (TransferException $e) {
            if ($e instanceof BadResponseException) {
                logger()->error('Received bad response when fetching Modrinth mod files.', ['response' => \GuzzleHttp\Psr7\Message::toString($e->getResponse())]);
            }
        }

        $file = $response['files'][0];
        $downloadUrl = $file['url'];

        return $downloadUrl;
    }

    public function getModLoaders(): array
    {

        return Cache::remember('modrinth-mod-loaders', 3600 * 24, function() {
            $response = json_decode($this->client->get('tag/loader')->getBody(), true);
            $modLoaders = [];

            foreach ($response as $loader) {
                if (in_array('mod', $loader['supported_project_types'])) {
                    $modLoaders[] = $loader['name'];
                }
            }
            return $modLoaders;
        });
    }
}
