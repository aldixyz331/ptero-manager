<?php

namespace Pterodactyl\Services\Minecraft\Mods;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\BadResponseException;
use GuzzleHttp\Exception\TransferException;
use Pterodactyl\Models\Server;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;
use Ramsey\Uuid\Uuid;

enum CurseForgeSortField: int
{
    case Featured = 1;
    case Popularity = 2;
    case LastUpdated = 3;
    case Name = 4;
    case Author = 5;
    case TotalDownloads = 6;
    case Category = 7;
    case GameVersion = 8;
    case EarlyAccess = 9;
    case FeaturedReleased = 10;
    case ReleasedDate = 11;
    case Rating = 12;
};

class CurseForgeModService extends AbstractModService
{
    public const CURSEFORGE_MINECRAFT_GAME_ID = 432;
    public const CURSEFORGE_MINECRAFT_MODS_CLASS_ID = 6;

    protected Client $client;

    public function __construct(protected DaemonFileRepository $daemonFileRepository)
    {
        parent::__construct($daemonFileRepository);

        $this->client = new Client([
            'headers' => [
                'User-Agent' => $this->userAgent,
                'X-API-Key' => config('services.curseforge_api_key'),
            ],
            'base_uri' => 'https://api.curseforge.com/v1/',
        ]);
    }

    public function search(array $filters): array
    {
        $query = $filters['searchQuery'];
        $pageSize = $filters['pageSize'];
        $page = $filters['page'];
        $minecraftVersion = $filters['minecraftVersion'];

        try {
            $response = json_decode($this->client->get('mods/search', [
                'query' => [
                    'index' => ($page - 1) * $pageSize,
                    'pageSize' => $pageSize,
                    'gameId' => self::CURSEFORGE_MINECRAFT_GAME_ID,
                    'classId' => self::CURSEFORGE_MINECRAFT_MODS_CLASS_ID,
                    'gameVersion' => $minecraftVersion,
                    'searchFilter' => $query,
                    'sortField' => CurseForgeSortField::Popularity->value,
                    'sortOrder' => 'desc',
                ],
            ])->getBody(), true);
        } catch (TransferException $e) {
            if ($e instanceof BadResponseException) {
                logger()->error('Received bad response when fetching CurseForge mods.', ['response' => \GuzzleHttp\Psr7\Message::toString($e->getResponse())]);
            }

            return [
                'data' => [],
                'total' => 0,
            ];
        }

        $mods = [];

        foreach ($response['data'] as $curseforgeMod) {
            $mods[] = [
                'id' => (string) $curseforgeMod['id'],
                'name' => $curseforgeMod['name'],
                'short_description' => $curseforgeMod['summary'],
                'url' => $curseforgeMod['links']['websiteUrl'],
                'icon_url' => isset($curseforgeMod['logo']) ? $curseforgeMod['logo']['thumbnailUrl'] : null,
            ];
        }

        // https://docs.curseforge.com/#search-mods
        // index + pageSize <= 10000
        $maximumPage = (10000 - $pageSize) / $pageSize + 1;

        return [
            'data' => $mods,
            'total' => min($maximumPage * $pageSize, $response['pagination']['totalCount']),
        ];
    }

    public function versions(string $modId, ?string $modLoader = null, ?string $minecraftVersion = null): array
    {
        try {
            $response = json_decode($this->client->get('mods/' . $modId . '/files')->getBody(), true);
        } catch (TransferException $e) {
            if ($e instanceof BadResponseException) {
                logger()->error('Received bad response when fetching CurseForge mods versions.', ['response' => \GuzzleHttp\Psr7\Message::toString($e->getResponse())]);
            }

            return [];
        }

        $versions = [];

        foreach ($response['data'] as $version) {
            $versions[] = [
                'id' => (string) $version['id'],
                'name' => $version['displayName'],
                'game_versions' => $version['gameVersions'],
                'download_url' => $version['downloadUrl'],
            ];
        }

        return $versions;
    }

    public function getDownloadUrl(string $modId, string $versionId): string
    {
        try {
            $response = json_decode($this->client->get('mods/' . $modId . '/files/' . $versionId)->getBody(), true);
        } catch (TransferException $e) {
            if ($e instanceof BadResponseException) {
                logger()->error('Received bad response when fetching CurseForge mod files.', ['response' => \GuzzleHttp\Psr7\Message::toString($e->getResponse())]);
            }
        }

        $file = $response['data'];
        $downloadUrl = str_replace("edge", "mediafiles", $file['downloadUrl']);

        return $downloadUrl;
    }

    /**
     * Returns normalized mod versions from $paths hashes.
     *
     * @param  array<string>  $paths
     */
    public function getModsVersions(Server $server, array $paths, ?array $serverBuildInfo = null): array
    {
        $hashes = array_filter($this->getCurseForgeFingerprints($server, $paths));
        $hashesToPaths = array_flip($hashes);
        
        $normalizedVersions = [];

        if (count($hashes) > 0) {
            $response = $this->client
                ->post('https://api.curseforge.com/v1/fingerprints/432',
                    [
                        'json' => [
                            'fingerprints' => array_values($hashes),
                        ],
                    ]);

            $statusCode = $response->getStatusCode();

            $data = ($statusCode >= 200 && $statusCode < 300) ? json_decode($response->getBody(), true)['data'] : [];

            foreach ($data['exactMatches'] as $curseForgeVersion) {
                $normalizedVersions[$curseForgeVersion['file']['modId']] = [
                    'path' => $hashesToPaths[(string) $curseForgeVersion['file']['fileFingerprint']],
                    'provider' => 'curseforge',
                    'project_id' => (string) $curseForgeVersion['id'],
                    'project_name' => null,
                    'version_id' => (string) $curseForgeVersion['file']['id'],
                    'version_name' => $curseForgeVersion['file']['displayName'],
                    'icon_url' => null,
                ];
            }
        }

        $mods = [];
        if (count($normalizedVersions) > 0) {
            $modsResponse = $this->client->post('mods',
            [
                'json' => [
                    'modIds' => array_keys($normalizedVersions),    
                ],
            ]);
            $mods = json_decode($modsResponse->getBody(), true)['data'];
        }
        foreach ($mods as $mod) {
            if (!isset($normalizedVersions[$mod['id']])) continue;
            $normalizedVersions[$mod['id']]['project_name'] = $mod['name'];
            $normalizedVersions[$mod['id']]['icon_url'] = $mod['logo']['url'] ?? null;
        }

        // Array of file paths for which no mod version could be found.
        $other = [];

        foreach ($hashes as $filePath => $hash) {
            if (! in_array((int) $hash, $data['exactFingerprints'])) {
                $other[] = $filePath;
            }
        }

        return ['identified' => array_values($normalizedVersions), 'other' => $other];
    }

    /**
     * Get CurseForge fingerprints for $paths.
     *
     * @param  array<string>  $paths
     * @return array<string, string>
     */
    public function getCurseForgeFingerprints(Server $server, array $paths): array
    {
        $fileRepository = $this->daemonFileRepository->setServer($server);

        $hashes = $fileRepository->getFingerprints($paths, 'curseforge');

        return $hashes;
    }
}
