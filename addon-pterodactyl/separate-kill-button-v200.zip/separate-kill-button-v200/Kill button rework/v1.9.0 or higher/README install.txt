Upload The Files to: 
/var/www/pterodactyl/

After That Run: cd /var/www/pterodactyl && yarn run build:production && chown -R www-data:www-data *
======================================================================================================
make sure you have Yarn and the panel dependencies installed!

# Install yarn
npm i -g yarn

# Make sure you are in your panel directory!
cd /var/www/pterodactyl

# Installs panel build dependencies
yarn install

========================================================================================
===================================================================================================
If you get an node error that looks like this update your nodejs to a version above the one that it expected

The engine "node" is incompatible with this module, Expected version ">=10". got "8.10.0"

To update nodejs to v14 use:
"curl -sL https://deb.nodesource.com/setup_14.x | sudo -E bash -
sudo apt-get install -y nodejs"
===================================================================================================