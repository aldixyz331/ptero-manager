@extends('layouts.admin')

@section('title')
    Ramlimit
@endsection

@section('content-header')
    <h1>RamLimit Configuration<small>Activate or deactivate the system, and configure its actions.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">RamLimit</li>
    </ol>
@endsection

@section('content')
    <div class="row">
        <div class="col-md-4 col-xs-12">
            <div class="box box-warning">
                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-fw fa-file-text"></i> System configuration</h3>
                </div>
                <form method="post" action="{{ route('admin.ramlimit.system')  }}">
                    <div class="box-body">
                        <div class="form-group">
                            <label for="ramlimit_status" class="form-label">Enable or disable</label>
                            <div>
                          <select class="form-control" name="ramlimit_status" id="ramlimit_status" required>
                          <option value="@if(isset($settings['ramlimit_status'])){{ $settings['ramlimit_status'] }}@endif" selected="">@isset($settings['ramlimit_status'])@if( $settings['ramlimit_status'] == "enable") System ON @else System OFF  @endif
                              @endisset</option>
                            <option value="enable">Enable</option>
                            <option value="disable">Disable</option>
                        </select>
                        </div>
                            <span class="text-muted small">Choose whether you want the system to be running or not.</span>
                        </div>
                        <div class="form-group">
                            <label for="ramlimit_action" class="form-label">Action</label>
                            <div>
                          <select class="form-control" name="ramlimit_action" id="ramlimit_action" required>
                          <option value="@if(isset($settings['ramlimit_action'])){{ $settings['ramlimit_action'] }}@endif" selected="">@isset($settings['ramlimit_action'])@if( $settings['ramlimit_action'] == "restart") It will restart @else Will be turned off  @endif
                              @endisset</option>
                            <option value="restart">Reboot</option>
                            <option value="kill">Kill</option>
                        </select>
                        </div>
                            <span class="text-muted small">Choose whether you want to <code>"REBOOT - KILL"</code> when the server exceeds the set ram limit. </span>
                        </div>
                        <div class="form-group">
                            <label for="ramlimit_percentage" class="form-label">Percentage</label>
                            <input type="text" name="ramlimit_percentage" id="ramlimit_percentage" class="form-control" value="{{ $settings['ramlimit_percentage'] }}" />
                            <span class="text-muted small">Choose at which percentage between <code>"0 and 99"</code> of ram usage the action should be executed.</span>
                        </div>
                    </div>
                    <div class="box-footer">
                        {!! csrf_field() !!}
                        <button type="submit" class="btn btn-success pull-right">Save</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-4 col-xs-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"><i class="fa fa-fw fa-inbox"></i> Discord Alert</h3>
                </div>
                <form method="post" action="{{ route('admin.ramlimit.discord')  }}">
                    <div class="box-body">
                        <div class="form-group">
                            <label for="ramlimit_discord_status" class="form-label">Enable or disable</label>
                        <div>
                          <select class="form-control" name="ramlimit_discord_status" id="ramlimit_discord_status" required>
                          <option value="@if(isset($settings['ramlimit_discord_status'])){{ $settings['ramlimit_discord_status'] }}@endif" selected="">@isset($settings['ramlimit_discord_status'])@if( $settings['ramlimit_discord_status'] == "enable") System ON @else System OFF  @endif
                              @endisset</option>
                            <option value="enable">Enable</option>
                            <option value="disable">Disable</option>
                        </select>
                        </div>
                        <span class="text-muted small">Choose whether you want the system to send messages to discord to be running or not.</span>
                        </div>
                        <div class="form-group">
                            <label for="ramlimit_discord_webhook" class="form-label">Link Webhook</label>
                            <input type="text" name="ramlimit_discord_webhook" id="ramlimit_discord_webhook" class="form-control" value="{{ $settings['ramlimit_discord_webhook'] }}" />
                            <span class="text-muted small">Enter here the link to your webhook (you can create it in the configuration of the channel where you want the messages to be sent).</span>
                        </div>
                        <div class="form-group">
                            <label for="ramlimit_discord_url" class="form-label">Panel URL</label>
                            <input type="text" name="ramlimit_discord_url" id="ramlimit_discord_url" class="form-control" value="{{ $settings['ramlimit_discord_url'] }}" />
                            <span class="text-muted small">Type here the link to your panel. <code>Without https:// or any slash /.</code> <b>Example panel.test.com</b></span>
                        </div>
                    </div>
                    <div class="box-footer">
                        {!! csrf_field() !!}
                        <button type="submit" class="btn btn-success pull-right">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

@endsection


