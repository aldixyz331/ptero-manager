<?php

namespace Pterodactyl\Console\Commands\Server;

use Pterodactyl\Models\Server;
use Illuminate\Console\Command;
use Illuminate\Cache\Repository;
use Pterodactyl\Repositories\Wings\DaemonPowerRepository;
use Pterodactyl\Repositories\Wings\DaemonServerRepository;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Illuminate\Support\Facades\DB;

class RamLimit extends Command
{
/** ------------------------------ Construction ------------------------------ */

    /** @var string */
    protected $signature = 'p:server:ramlimit';

    /** @var string */
    protected $description = 'Perform an action when a ram limit is reached.';

    /** @var \Pterodactyl\Contracts\Repository\SettingsRepositoryInterface */
    private SettingsRepositoryInterface $settingsRepository;

    /** @var \Pterodactyl\Repositories\Wings\DaemonServerRepository */
    private DaemonServerRepository $repository;

    /** @var \Illuminate\Cache\Repository */
    private Repository $cache;

    public function __construct(Repository $cache, DaemonServerRepository $repository, DaemonPowerRepository $power, SettingsRepositoryInterface $settingsRepository)
    {
        parent::__construct();

        $this->cache = $cache;
        $this->repository = $repository;
        $this->power = $power;
        $this->settingsRepository = $settingsRepository;
    }

    /** ------------------------------ Function ------------------------------ */
    public function handle()
    {
$status = $this->settingsRepository->get('settings::ramlimit::ramlimit_status', 'disable');
$statusdc = $this->settingsRepository->get('settings::ramlimit::ramlimit_discord_status', 'disable');
$action = $this->settingsRepository->get('settings::ramlimit::ramlimit_action', '');
$percentage = $this->settingsRepository->get('settings::ramlimit::ramlimit_percentage', '');

$servers = Server::all();

        foreach($servers as $server) {
            $key = "resources:{$server->uuid}";
            $nodeid = DB::table('servers')->where('id', '=', $server->id)->value('node_id');
            $nodestatus = DB::table('nodes')->where('id', '=', $nodeid)->value('maintenance_mode');
              try {
            $stats = $this->repository->setServer($server)->getDetails();
            $usage1 = (int)($stats['utilization']['memory_bytes']/ 1048576);
            $usage2 = (float)$usage1;
            $limit = $server->memory;

    if(number_format((100.0*$usage2)/$limit, 1) > $percentage) {
        if ($status == 'enable') {
            $this->power->setServer($server)->send($action);
        }
        if ($statusdc == 'enable') {
            $this->m1($server);
        }   
       }

      } catch (\Throwable $e) {
        $cc = NULL;
    }
      
      } 
     return 0;
    
   }
   
private function m1($server) {
    $iduser = $server->owner_id;
    $idsv = $server->id;
    $email = DB::table('users')->where('id', '=', $iduser)->value('email');
    $uuid = DB::table('servers')->where('id', '=', $idsv)->value('uuidShort');
    $namesv = DB::table('servers')->where('id', '=', $idsv)->value('name');
    $nodeid = DB::table('servers')->where('id', '=', $idsv)->value('node_id');
    $webhook = $this->settingsRepository->get('settings::ramlimit::ramlimit_discord_webhook', '');
    $url = $this->settingsRepository->get('settings::ramlimit::ramlimit_discord_url', '');
    $webkey = $webhook;  
    $timestamp = date("c", strtotime("now"));
    $json_data = json_encode([
        "content" => "",
        "embeds" => [
          [
            "title" => "⚠️ Ram limit on a server ⚠️",
            "type" => "rich",
            "description" => "[SEE SERVER](https://$url/admin/servers/view/$idsv) // [SEE USER](https://$url/admin/users?filter%5Bemail%5D=$email)",
            "timestamp" => $timestamp,
            "color" => hexdec("f90e00"),
            "fields" => [
                [
                    "name" => "Server creator ID:",
                    "value" => $iduser,
                    
                    "inline" => true
                  ],
                  [
                    "name" => "Email of the server creator:",
                    "value" => $email,
                    "inline" => true
                  ],
                  [
                      "name" => "UUID of the server:",
                      "value" => $uuid,
                      "inline" => true
                    ],
                    [
                        "name" => "Server name:",
                        "value" => $namesv,
                        "inline" => true
                      ],
          ]
        ]
      ]
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $ch = curl_init($webkey);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $response = curl_exec($ch);
    curl_close($ch);
  }
}


