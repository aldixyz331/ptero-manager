<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class RamLimitController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    protected $alert;

    /**
     * @var \Pterodactyl\Contracts\Repository\SettingsRepositoryInterface
     */
    private $settings;

    /**
     * RamLimitController constructor.
     * @param AlertsMessageBag $alert
     * @param SettingsRepositoryInterface $settings
     */
    public function __construct(AlertsMessageBag $alert, SettingsRepositoryInterface $settings)
    {
        $this->alert = $alert;
        $this->settings = $settings;
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        return view('admin.ramlimit.index', [
            'settings' => [
                'ramlimit_status' => $this->settings->get('settings::ramlimit::ramlimit_status', 'disable'),
                'ramlimit_action' => $this->settings->get('settings::ramlimit::ramlimit_action', ''),
                'ramlimit_percentage' => $this->settings->get('settings::ramlimit::ramlimit_percentage', ''),
                'ramlimit_discord_status' => $this->settings->get('settings::ramlimit::ramlimit_discord_status', 'disable'),
                'ramlimit_discord_webhook' => $this->settings->get('settings::ramlimit::ramlimit_discord_webhook', ''),
                'ramlimit_discord_url' => $this->settings->get('settings::ramlimit::ramlimit_discord_url', ''),
            ]
        ]);
    }

    /**
     * @param Request $request
     * @return RedirectResponse
     * @throws \Illuminate\Validation\ValidationException
     * @throws \Pterodactyl\Exceptions\Model\DataValidationException
     * @throws \Pterodactyl\Exceptions\Repository\RecordNotFoundException
     */
    public function system(Request $request)
    {
        $this->validate($request, [
            'ramlimit_status' => 'required|max:100',
            'ramlimit_action' => 'required|max:100',
            'ramlimit_percentage' => 'required|min:0|max:99|integer'
        ]);

        $status = trim($request->input('ramlimit_status'));
        $action = trim($request->input('ramlimit_action'));
        $percentage = trim($request->input('ramlimit_percentage'));

        $this->settings->set('settings::ramlimit::ramlimit_status', $status);
        $this->settings->set('settings::ramlimit::ramlimit_action', $action);
        $this->settings->set('settings::ramlimit::ramlimit_percentage', $percentage);

        $this->alert->success('You have successfully updated settings.')->flash();
        return redirect()->route('admin.ramlimit');
    }

    /**
     * @param Request $request
     * @return RedirectResponse
     * @throws \Illuminate\Validation\ValidationException
     * @throws \Pterodactyl\Exceptions\Model\DataValidationException
     * @throws \Pterodactyl\Exceptions\Repository\RecordNotFoundException
     */
    public function discord(Request $request)
    {
        $this->validate($request, [
            'ramlimit_discord_status' => 'required|max:100',
            'ramlimit_discord_webhook' => 'required|max:200',
            'ramlimit_discord_url' => 'required|max:100',
        ]);

        $statusdc = trim($request->input('ramlimit_discord_status'));
        $webhook = trim($request->input('ramlimit_discord_webhook'));
        $url = trim($request->input('ramlimit_discord_url'));

        $this->settings->set('settings::ramlimit::ramlimit_discord_status', $statusdc);
        $this->settings->set('settings::ramlimit::ramlimit_discord_webhook', $webhook);
        $this->settings->set('settings::ramlimit::ramlimit_discord_url', $url);
        
        $this->alert->success('You have successfully updated settings.')->flash();
        return redirect()->route('admin.ramlimit');
    }


}
