Thanks for purchasing Node Maintenance by harrydev!

Need support? Join my Discord! https://harryw.link/discord

=== PANEL CHANGES ====
1) Upload the files inside the Panel folder to /var/www/pterodactyl (or wherever your panel files are stored)

2) Make the changes to existing files as documented in EXISTING_FILES.txt

3) Run "cd /var/www/pterodactyl && yarn && yarn build:production", or follow the guide here: https://pterodactyl.io/community/customization/panel.html
