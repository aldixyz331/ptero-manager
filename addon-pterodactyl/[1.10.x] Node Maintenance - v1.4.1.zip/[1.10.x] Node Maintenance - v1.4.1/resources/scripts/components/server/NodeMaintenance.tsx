import React from 'react';
import ScreenBlock from '@/components/elements/ScreenBlock';
import NodeMaintenanceSvg from '@/assets/images/node_maintenance.svg';

export default () => {
    return (
        <ScreenBlock
            title={'Under Maintenance'}
            image={NodeMaintenanceSvg}
            message={'Your node is currently under maintenance. Please check back later.'}
        />
    );
};
