<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Pterodactyl\Models\DiscordEmbedLang;

return new class extends Migration
{
    private $lang = [
        'api.client.account.two-factor.post' => 'Two-factor authentication enabled',
        'api.client.account.two-factor.delete' => 'Two-factor authentication disabled',

        'api.client.account.email.put' => 'Account email updated',
        'api.client.account.password.put' => 'Account password updated',

        'api.client.account.api-keys.post' => 'New API key created',
        'api.client.account.api-keys.identifier.delete' => 'API key deleted',

        'api.client.account.ssh-keys.post' => 'New SSH key created',
        'api.client.account.ssh-keys.remove.post' => 'SSH key deleted',

        'api.client.servers.server.command.post' => 'Server command sent',
        'api.client.servers.server.power.post' => 'Server power sent',
        'api.client.servers.server.databases.post' => 'Server database created',
        'api.client.servers.server.databases.database.rotate-password.post' => 'Server database password rotated',
        'api.client.servers.server.databases.database.delete' => 'Server database deleted',
        'api.client.servers.server.files.rename.put' => 'Server file renamed',
        'api.client.servers.server.files.copy.post' => 'Server file copied',
        'api.client.servers.server.files.write.post' => 'Server file written',
        'api.client.servers.server.files.compress.post' => 'Server files compressed',
        'api.client.servers.server.files.decompress.post' => 'Server files decompressed',
        'api.client.servers.server.files.delete.post' => 'Server file deleted',
        'api.client.servers.server.files.create-folder.post' => 'Server folder created',
        'api.client.servers.server.files.chmod.post' => 'Server file permissions changed',
        'api.client.servers.server.files.pull.post' => 'Server files pulled',
        'api.client.servers.server.files.upload.get' => 'Server file upload started',
        'api.client.servers.server.schedules.post' => 'Server schedule created',
        'api.client.servers.server.schedules.schedule.post' => 'Server schedule updated',
        'api.client.servers.server.schedules.schedule.execute.post' => 'Server schedule executed',
        'api.client.servers.server.schedules.schedule.delete' => 'Server schedule deleted',
        'api.client.servers.server.schedules.schedule.tasks.post' => 'Server schedule task created',
        'api.client.servers.server.schedules.schedule.tasks.task.post' => 'Server schedule task updated',
        'api.client.servers.server.schedules.schedule.tasks.task.delete' => 'Server schedule task deleted',
        'api.client.servers.server.network.allocations.post' => 'Server allocation created',
        'api.client.servers.server.network.allocations.allocation.post' => 'Server allocation updated',
        'api.client.servers.server.network.allocations.allocation.delete' => 'Server allocation deleted',
        'api.client.servers.server.network.allocations.allocation.primary.post' => 'Server allocation assigned',
        'api.client.servers.server.users.post' => 'Server subuser created',
        'api.client.servers.server.users.user.post' => 'Server subuser updated',
        'api.client.servers.server.users.user.delete' => 'Server subuser deleted',
        'api.client.servers.server.backups.post' => 'Server backup created',
        'api.client.servers.server.backups.backup.lock.post' => 'Server backup lock toggled',
        'api.client.servers.server.backups.backup.restore.post' => 'Server backup restored',
        'api.client.servers.server.backups.backup.delete' => 'Server backup deleted',
        'api.client.servers.server.startup.variable.put' => 'Server startup updated',
        'api.client.servers.server.settings.rename.post' => 'Server name updated',
        'api.client.servers.server.settings.reinstall.post' => 'Server reinstalled',
        'api.client.servers.server.settings.docker-image.put' => 'Server docker image updated',

        'api.client.servers.server.signal.get' => 'Server power sent',
    ];

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        foreach ($this->lang as $key => $value) {
            DiscordEmbedLang::create([
                'key' => $key,
                'message' => $value,
            ]);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

        foreach ($this->lang as $key => $value) {
            DiscordEmbedLang::where('key', $key)->delete();
        }
    }
};
