<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('discord_webhook', function (Blueprint $table) {
            $table->increments('id');
            $table->string('webhook_url');
            $table->string('username');
            $table->string('embed_color');
            $table->string('embed_author');
            $table->timestamps();
        });

        DB::table('discord_webhook')->insert([
            'webhook_url' => 'https://discord.com/api/webhooks/...',
            'username' => 'Pterodactyl Panel',
            'embed_color' => '#2020FF',
            'embed_author' => 'Pterodactyl Panel',
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('discord_webhook');
    }
};
