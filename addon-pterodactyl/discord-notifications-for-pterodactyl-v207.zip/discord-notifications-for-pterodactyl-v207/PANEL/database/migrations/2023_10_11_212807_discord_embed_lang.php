<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('discord_webhook_messages', function (Blueprint $table) {
            $table->increments('id');
            $table->string('key')->unique();
            $table->string('message');
            $table->timestamps();
        });

        $lang = [
            'admin.api.new.post' => 'New admin API key created',
            'admin.api.revoke.identifier.delete' => 'Admin API key revoked',

            'admin.locations.post' => 'New location created',
            'admin.locations.view.location.patch' => 'Location updated',

            'admin.databases.post' => 'New database created',
            'admin.databases.view.host.patch' => 'Database host updated',
            'admin.databases.view.host.delete' => 'Database host deleted',

            'admin.settings.mail.test.post' => 'Mail test sent',
            'admin.settings.patch' => 'Panel settings updated',
            'admin.settings.mail.patch' => 'Mail settings updated',
            'admin.settings.advanced.patch' => 'Advanced settings updated',

            'admin.users.new.post' => 'New user created',
            'admin.users.view.user.patch' => 'User updated',
            'admin.users.view.user.delete' => 'User deleted',

            'admin.servers.new.post' => 'New server created',
            'admin.servers.view.server.build.post' => 'Server build started',
            'admin.servers.view.server.startup.post' => 'Server startup updated',
            'admin.servers.view.server.database.post' => 'Server database created',
            'admin.servers.view.server.mount.post' => 'Server mount created',
            'admin.servers.view.server.manage.toggle.post' => 'Server install status toggled',
            'admin.servers.view.server.manage.suspension.post' => 'Server suspension toggled',
            'admin.servers.view.server.manage.reinstall.post' => 'Server reinstalled',
            'admin.servers.view.server.manage.transfer.post' => 'Server transferred',
            'admin.servers.view.server.delete.post' => 'Server deleted',
            'admin.servers.view.server.details.patch' => 'Server details updated',
            'admin.servers.view.server.database.patch' => 'Server database updated',
            'admin.servers.view.server.database.database.dalete.delete' => 'Server database deleted',
            'admin.servers.view.server.mount.mount.delete' => 'Server mount deleted',

            'admin.nodes.new.post' => 'New node created',
            'admin.nodes.view.node.allocation.post' => 'Node allocation created',
            'admin.nodes.view.node.allocation.delete' => 'Node allocation deleted',
            'admin.nodes.view.node.allocation.alias.post' => 'Node allocation alias created',
            'admin.nodes.view.node.settings.token.post' => 'Node token updated',
            'admin.nodes.view.node.settings.patch' => 'Node settings updated',
            'admin.nodes.view.node.delete' => 'Node deleted',
            'admin.nodes.view.node.allocation.remove.allocation.delete' => 'Node allocation removed',
            'admin.nodes.view.node.allocations.delete' => 'Node allocations deleted',

            'admin.mounts.post' => 'New mount created',
            'admin.mounts.mount.eggs.post' => 'Mount eggs updated',
            'admin.mounts.mount.nodes.post' => 'Mount nodes updated',
            'admin.mounts.view.mount.patch' => 'Mount updated',
            'admin.mounts.mount.eggs.egg_id.delete' => 'Mount egg removed',
            'admin.mounts.mount.nodes.node_id.delete' => 'Mount node removed',

            'admin.nests.new.post' => 'New nest created',
            'admin.nests.view.nest.patch' => 'Nest updated',
            'admin.nests.nest.delete' => 'Nest deleted',

            'admin.nests.egg.new.post' => 'New egg created',
            'admin.nests.egg.view.egg.patch' => 'Egg updated',
            'admin.nests.egg.export.get' => 'Egg exported',
            'admin.nests.egg.variables.post' => 'Egg variable created',
            'admin.nests.egg.scripts.patch' => 'Egg scripts updated',
            'admin.nests.egg.variables.edit.patch' => 'Egg variable updated',
            'admin.nests.egg.delete' => 'Egg deleted',
            'admin.nests.egg.variables.edit.delete' => 'Egg variable deleted',
            'admin.nests.egg.update.put' => 'Egg updated',

            'admin.myplugins.discord.patch' => 'Discord settings updated',
            'admin.myplugins.discord.lang.post' => 'MyPlugins Discord Message created',
            'admin.myplugins.discord.lang.id.patch' => 'MyPlugins Discord Message updated',
        ];

        foreach ($lang as $key => $message) {
            DB::table('discord_webhook_messages')->insert([
                'key' => $key,
                'message' => $message,
            ]);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('discord_webhook_messages');
    }
};
