<?php

namespace Pterodactyl\Http\Controllers\Admin\MyPlugins;

use Illuminate\Http\Request;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\DiscordEmbedLang;
use Pterodactyl\Models\DiscordWebhook;

class DiscordController extends Controller
{
    protected $alert;
    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    /**
     * Display view
     */
    public function index()
    {
        // lang with pagination
        $lang = DiscordEmbedLang::paginate(10);

        return view('admin.myplugins.discord.index', [
            'webhook' => DiscordWebhook::first(),
            'lang' => $lang
        ]);
    }

    /**
     * Update webhook
     */
    public function update(Request $request)
    {
        $webhook = DiscordWebhook::first();
        $webhook->webhook_url = $request->input('webhook_url');
        $webhook->username = $request->input('username');
        $webhook->embed_color = $request->input('embed_color');
        $webhook->embed_author = $request->input('embed_author');
        $webhook->save();

        $this->alert->success('Webhook updated successfully.')->flash();

        return redirect()->route('admin.myplugins.discord');
    }

    /**
     * Update lang
     */
    public function updateLang(Request $request, $id)
    {
        $this->validate($request, [
            'key' => 'unique:discord_webhook_messages,key',
            'message' => 'required'
        ]);
        
        $lang = DiscordEmbedLang::findOrFail($id);
        $lang->message = $request->input('message');
        $lang->key = $request->input('key');
        $lang->save();

        $this->alert->success('Message updated successfully.')->flash();

        return redirect()->route('admin.myplugins.discord');
    }

    /**
     * Create lang
     */
    public function createLang(Request $request)
    {
        $this->validate($request, [
            'key' => 'unique:discord_webhook_messages,key',
            'message' => 'required'
        ]);

        $lang = new DiscordEmbedLang;
        $lang->message = $request->input('message');
        $lang->key = $request->input('key');
        $lang->save();

        $this->alert->success('Message created successfully.')->flash();

        return redirect()->route('admin.myplugins.discord');
    }
}
