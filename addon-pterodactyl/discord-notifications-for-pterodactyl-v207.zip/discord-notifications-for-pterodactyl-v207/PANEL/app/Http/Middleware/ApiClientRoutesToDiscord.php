<?php

namespace Pterodactyl\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\DiscordEmbedLang;
use Pterodactyl\Models\DiscordWebhook;

class ApiClientRoutesToDiscord
{
    protected $alert;

    private $allow_get= [
        'api/client/servers/{server}/files/upload',
        'api/client/servers/{server}/signal'
    ];

    /**
     * Constructor
     */
    public function __construct(
        AlertsMessageBag $alert
    ) {
        $this->alert = $alert;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        try {
            $r = $next($request);
            $w = DiscordWebhook::first();

            // check if the user is logged in
            if (!Auth::check()) {
                return $r;
            }

            // check ig this is a post request
            if ($request->isMethod('get') && !in_array($request->route()->uri(), $this->allow_get)) {
                return $r;
            }

            // verify the only key in $alert->getMessages() is 'success'

            $errors = [];

            if ($request->session())
            {
                $errors = $request->session()->get('errors');
                if (!is_null($errors)) {
                    $errors = $errors->getMessages();
                } else {
                    $errors = [];
                }
                if (!isset($this->alert->getMessages()['success']) && count($this->alert->getMessages()) >= 1 || count($errors) > 0) {
                    return $r;
                }
            }

            $changes = $request->all();

            //dd($changes);

            // remove critical data
            unset($changes['password']);
            unset($changes['password_confirmation']);

            //unset everything that starts with _
            foreach ($changes as $key => $value) {
                if (substr($key, 0, 1) == '_') {
                    unset($changes[$key]);
                }
            }

            // unset empty values
            foreach ($changes as $key => $value) {
                if (empty($value)) {
                    unset($changes[$key]);
                }
            }

            $changes['User'] = Auth::user()->username;

            $route = [
                'name' => $request->route()->uri(),
                'methods' => $request->method(),
                'parameters' => $request->route()->parameters(),
                'changes' => $changes,
                'complete_url' => $request->fullUrl(),
            ];

            $route_lang = str_replace('/', '.', $route['name']).'.'.strtolower($route['methods']);
            $route_lang = str_replace('{', '', $route_lang);
            $route_lang = str_replace('}', '', $route_lang);

            if (DiscordEmbedLang::where('key', $route_lang)->exists()) {
                $route['message'] = DiscordEmbedLang::where('key', $route_lang)->first()->message;
            } else {
                $route['methods'] = ($request->method() == 'POST' ? 'created' : strtolower($request->method()) . "ed");
                $route_name = str_replace('/', ' ', $route['name']);

                if (substr($route_name, 0, 1) == ' ') {
                    $route_name = substr($route_name, 1);
                }

                $route_name = explode(' ', $route_name, 2)[1];

                if (substr($route_name, -1) == 's') {
                    $route_name = substr($route_name, 0, -1);
                }

                $route_name = ucfirst($route_name);
                $route['message'] = '🚧 ' . $route_name . ' ' . $route['methods'];
            }

            // format as embed for discord
            $embed = [
                'title' => $route['message'],
                'type' => 'rich',
                'url' => $route['complete_url'],
                'color' => hexdec($w->embed_color),
                'fields' => [],
                'timestamp' => date('c'),
                'author' => [
                    'name' => $w->embed_author,
                ],
            ];
            $webhook_url = $w->webhook_url;

            // if this is a server route, add the server name
            if (isset($route['parameters']['server'])) {
                $route['changes']['Server'] = $route['parameters']['server']->name;
                $route['changes']['Server UUID'] = $route['parameters']['server']->uuidShort;

                if(!empty($route['parameters']['server']->webhook_url)) {
                    $webhook_url = $route['parameters']['server']->webhook_url;
                }
            }

            // add the rest of the parameters
            foreach ($route['changes'] as $key => $value) {
                // convert all to string
                if (is_array($value)) {
                    $tmp = [];
                    foreach ($value as $k => $v) {
                        if (is_array($v)) {
                            foreach ($v as $k2 => $v2) {
                                $tmp[$k2] = $v2;
                            }
                        } else {
                            $tmp[$k] = $v;
                        }
                    }
                    $value = json_encode($tmp);
                } elseif (is_bool($value)) {
                    $value = $value ? 'true' : 'false';
                } elseif (is_object($value)) {
                    $value = json_encode($value);
                } elseif (is_null($value)) {
                    $value = 'null';
                } elseif (is_numeric($value)) {
                    $value = (string) $value;
                }

                $embed['fields'][] = [
                    'name' => ucfirst(str_replace('_', ' ', $key)),
                    'value' => $value,
                    'inline' => true,
                ];
            }

            $message = [
                'username' => $w->username,
                'embeds' => [$embed],
            ];

            // send the message to discord
            $c = curl_init($webhook_url."?wait=true");
            curl_setopt($c, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($c, CURLOPT_POST, 1);
            curl_setopt($c, CURLOPT_POSTFIELDS, json_encode($message));
            curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
            curl_exec($c);
            curl_close($c);

            return $r;
        } catch (\Exception $e) {
            // if there is an error, log it
            \Log::error('Error in ApiClientRoutesToDiscord middleware: ' . $e->getMessage());
            return $next($request);
        }
    }
}
