<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
/**
 * \Pterodactyl\Models\DiscordWebhook.
 *
 * @property int $id
 * @property string $webhook_url
 * @property string $username
 * @property string $embed_color
 * @property string $embed_author
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 *
 * @mixin \Eloquent
 */
class DiscordWebhook extends Model
{
    use HasFactory;

    protected $table = 'discord_webhook';

    protected $guarded = ['id'];

    protected $casts = [
        'webhook_url' => 'string',
        'username' => 'string',
        'embed_color' => 'string',
        'embed_author' => 'string',
    ];

    protected $fillable = [
        'webhook_url',
        'username',
        'embed_color',
        'embed_author',
    ];

    protected $validationRules = [
        'webhook_url' => 'required',
        'username' => 'required',
        'embed_color' => 'required',
        'embed_author' => 'required',
    ];


}
