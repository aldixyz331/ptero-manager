<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * \Pterodactyl\Models\DiscordEmbedLang.
 *
 * @property int $id
 * @property string $key
 * @property string $message
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 *
 * @mixin \Eloquent
 */

class DiscordEmbedLang extends Model
{
    use HasFactory;

    protected $table = 'discord_webhook_messages';

    protected $guarded = ['id'];

    protected $casts = [
        'key' => 'string',
        'message' => 'string',
    ];

    protected $fillable = [
        'key',
        'message',
    ];

    protected $validationRules = [
        'key' => 'required',
        'message' => 'required',
    ];
}
