@extends('layouts.admin')

@section('title')
    Discord notifications
@endsection

@section('content-header')
    <h1>Discord notifications<small>This part allows you to configure this addon.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li>MyPlugins</li>
        <li class="active">Discord Notifications</li>
    </ol>
@endsection

@section('content')
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title">Discord notifications</h3>
                </div>
                <div class="box-body">
                    <p>Discord Notifications was made with <i class="fa fa-heart"></i> by MyPlugins</p>
                    <p>You can get support on this <a href="https://discord.gg/RJ2A8yYS2m" target="_blank">Discord</a>.</p>
                </div>
            </div>
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Settings</h3>
                </div>
                <div class="box-body">
                    <div class="box-body table-responsive no-padding">
                        <form method="post">
                            @method('PATCH')
                            {{-- url --}}
                            <div class="form-group col-xs-12">
                                <label class="control-label">Discord Webhook</label>
                                <div>
                                    <input type="text" class="form-control" name="webhook_url" value="{{ $webhook->webhook_url }}">
                                    <p class="text-muted"><small>Enter your Discord webhook url.</small></p>
                                </div>
                            </div>
                            {{-- username --}}
                            <div class="form-group col-xs-5">
                                <label class="control-label">Discord username</label>
                                <div>
                                    <input type="text" class="form-control" name="username" value="{{ $webhook->username }}">
                                </div>
                            </div>
                            {{-- embed author --}}
                            <div class="form-group col-xs-5">
                                <label class="control-label">Discord embed author</label>
                                <div>
                                    <input type="text" class="form-control" name="embed_author" value="{{ $webhook->embed_author }}">
                                </div>
                            </div>
                            {{-- embed_color --}}
                            <div class="form-group col-xs-2">
                                <label class="control-label">Discord embed color</label>
                                <div>
                                    <input type="color" class="form-control" name="embed_color" value="{{ $webhook->embed_color }}">
                                </div>
                            </div>
                            <div class="form-group col-xs-12">
                                <div>
                                    {!! csrf_field() !!}
                                    <button type="submit" class="btn btn-sm btn-primary pull-right">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Messages</h3>
                </div>
                <div class="box-body">
                    <p>If you don't know what you do, DO NOT EDIT ! ❌</p>
                    <p>To know how is defined the key, for exemple a post method on <span class="text-muted">/admin/api/new</span>, the key is <span class="text-muted">admin.api.new.post</span> . If you have a question, go on our discord.</p>

                    <div class="box-body table-responsive no-padding">
                        <div class="box-tools pull-right">
                            {{ $lang->links() }}
                        </div>
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>key</th>
                                    <th>message</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($lang as $lang_key)
                                    <tr>
                                        <form action="{{ route('admin.myplugins.discord.lang.update', $lang_key->id) }}" method="post">
                                            @csrf
                                            @method('PATCH')
                                            <td>
                                                <input type="text" class="form-control" name="key" value="{{ $lang_key->key }}">
                                            </td>
                                            <td>
                                                <input type="text" class="form-control" name="message" value="{{ $lang_key->message }}">
                                            </td>
                                            <td>
                                                <button type="submit" class="btn btn-sm btn-primary pull-right">Save</button>
                                            </td>
                                        </form>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="2">No message, make sure you do the migration.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    <div class="box-body table-responsive pt-3">
                        <form method="post" action="{{ route('admin.myplugins.discord.lang.create') }}">
                            {{-- url --}}
                            <div class="form-group col-xs-6">
                                <label class="control-label">Key</label>
                                <div>
                                    <input type="text" class="form-control" name="key" value="{{ old('key') }}">
                                    <p class="text-muted"><small>Enter the key of the message.</small></p>
                                </div>
                            </div>
                            {{-- username --}}
                            <div class="form-group col-xs-6">
                                <label class="control-label">Message</label>
                                <div>
                                    <input type="text" class="form-control" name="message" value="{{ old('message') }}">
                                </div>
                            </div>
                            <div class="form-group col-xs-12">
                                <div>
                                    {!! csrf_field() !!}
                                    <button type="submit" class="btn btn-sm btn-primary pull-right">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
