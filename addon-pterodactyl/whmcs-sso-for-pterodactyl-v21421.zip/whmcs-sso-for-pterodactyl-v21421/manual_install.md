# Welcome
Welcome and thanks for buying this product, WHMCS SSO for Pterodactyl!
Contact information is available at the end of this document. Please don't hesitate to reach out if you have any questions.
If you are reading the PDF, you may have an easier time copying around the code samples from the markdown file in the same directory as the PDF, under the name `README.md`.

ROOT DIRECTORY = Where the Pterodactyl Panel is installed (usually `/var/www/pterodactyl`).

# Set Up

1. Please generate OpenID credentials in Setup > OpenID Connect with the Redirection URL like this : "https://my.panel/auth/oauth/whmcs/callback" (replace my.panel with your panel domain) in WHMCS.
2. Please execute `composer require laravel/socialite` in your root directory.
3. Upload the files that are in `upload/` to your root directory. Note that this can conflict with another addon that changes the authentication process of the panel.
4. Run the following command: `php artisan migrate` in your root directory.
5. Edit the following files as specified (paths are from the root directory).

# `.env`

Add the following lines at the end of the file, replacing with your WHMCS instance information:
```shell
WHMCS_URL=https://billing.company.com
WHMCS_CLIENT_ID=123456789
WHMCS_CLIENT_SECRET=123456789
```

Also, make sure that your `APP_URL` doesn't include any trailing slash.

# `config/services.php`

Add this after line 35 in `config/services.php` (copy-paste it exactly as is, without any modifications to the `env` invocations) :
```php

    'whmcs' => [
        'url' => env('WHMCS_URL'),
        'client_id' => env('WHMCS_CLIENT_ID'),
        'client_secret' => env('WHMCS_CLIENT_SECRET'),
        'redirect' => env('WHMCS_REDIRECT', env('APP_URL') . '/auth/oauth/whmcs/callback'),
    ],
```

# `app/Models/User.php`

Edit the file as follows:
```diff
        'gravatar',
        'root_admin',
+        'whmcs_user_token',
    ];
```

# `app/Providers/AppServiceProvider.php`

Edit the file as follows:

```diff
use Pterodactyl\Models;
+use Pterodactyl\Socialite\WHMCSProvider;
use Illuminate\Support\Str;
```

```diff
        Relation::enforceMorphMap([
            'allocation' => Models\Allocation::class,
            'api_key' => Models\ApiKey::class,
            'backup' => Models\Backup::class,
            'database' => Models\Database::class,
            'egg' => Models\Egg::class,
            'egg_variable' => Models\EggVariable::class,
            'schedule' => Models\Schedule::class,
            'server' => Models\Server::class,
            'ssh_key' => Models\UserSSHKey::class,
            'task' => Models\Task::class,
            'user' => Models\User::class,
        ]);
        
+        $socialite = $this->app->make('Laravel\Socialite\Contracts\Factory');
+        $socialite->extend(
+            'whmcs',
+            function ($app) use ($socialite) {
+                $config = $app['config']['services.whmcs'];
+                return $socialite->buildProvider(WHMCSProvider::class, $config);
+            }
+        );
```

# `routes/auth.php`

After this line:
```php
    Route::get('/login', [Auth\LoginController::class, 'index'])->name('auth.login');
```

add these lines:

```php
    Route::get('/oauth/{provider}', [Auth\LoginController::class, 'redirectToProvider'])->name('auth.oauth');
    Route::get('/oauth/{provider}/callback', [Auth\LoginController::class, 'handleProviderCallback'])->name('auth.oauth.callback');
```

# `resources/scripts/components/auth/LoginContainer.tsx`

Under `import useFlash from '@/plugins/useFlash';`, add this line :

```tsx
import http from '@/api/http';
```

Before this line `const onSubmit = (values: Values, { setSubmitting }: FormikHelpers<Values>) => {`, add these lines :

```tsx
    const useWHMCS = () => {
        http.get('/auth/oauth/whmcs')
            .then(response => {
                window.location = response.data.redirect;
            });
    };
```

Under these lines: 
```tsx
                        <Link
                            to={'/auth/password'}
                            css={tw`text-xs text-neutral-500 tracking-wide no-underline uppercase hover:text-neutral-600`}
                        >
                            Forgot password?
                        </Link>
```

Add this line:
```tsx
<a href="#" css={tw`ml-1 text-xs text-neutral-500 tracking-wide no-underline uppercase hover:text-neutral-600`} onClick={useWHMCS}>Use WHMCS?</a>
```

Note: You can place this element wherever you want your link to be placed on the page and change the text to your liking.

If you're going to use a Node.js version greater than or equal to 17.x, you may encounter errors due to an incompatibility between the new OpenSSL and the version of Webpack used by Pterodactyl. As a workaround, set this environment variable before building assets:

```bash
export NODE_OPTIONS=--openssl-legacy-provider
```

Finally, execute these commands in your root directory to build your Pterodactyl Panel's front-end assets:
```shell
npm install --global yarn # install yarn if you don't already have it
yarn install
yarn run build:production
```

It should be good now!
If you have any questions about this product or need help with its installation,
You can contact us using the following services:
- Discord: https://discord.gg/RJ2A8yYS2m
- Email: contact@ric-rac.org
- X: @ricxracx