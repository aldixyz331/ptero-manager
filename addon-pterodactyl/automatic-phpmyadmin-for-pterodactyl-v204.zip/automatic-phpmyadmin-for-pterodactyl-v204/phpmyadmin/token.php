<?php
declare(strict_types=1);
ini_set('session.use_cookies', 'true');

/* Change this to false if using phpMyAdmin over http */
$secure_cookie = true;

session_set_cookie_params(0, '/', '', $secure_cookie, true);
$session_name = 'TokenSession';
session_name($session_name);
@session_start();

// Change this to an alpha-numeric string of the legth of your choice
$encryption_key = 'supersecretencryptionkey';
// Change this to an 16 digits string of your choice
$encryption_iv = 'supersecretvector';
// The cookie name of your choice
$cookie_name = 'token';
// The domain of your PhpMyAdmin installation
$cookie_domain = '.example.xyz';

if(isset($_COOKIE[$cookie_name])) {
    $decryption = openssl_decrypt($_COOKIE[$cookie_name], "AES-128-CTR", $encryption_key, 0, $encryption_iv);
    $response = json_decode($decryption, true);

    $_SESSION['PMA_single_signon_user'] = $response['database_username'];
    $_SESSION['PMA_single_signon_password'] = $response['database_password'];
    $_SESSION['PMA_single_signon_port'] = '3306';
    $_SESSION['PMA_single_signon_HMAC_secret'] = hash('sha1', uniqid(strval(random_int(0, mt_getrandmax())), true));
    $id = session_id();
    @session_write_close();

    setcookie($cookie_name, "", time(), '/', $cookie_domain);
    header("Location: ../index.php?server={$response['phpmyadmin_server_id']}");
} else {
    header('Content-Type: text/html; charset=utf-8');
    echo '<?xml version="1.0" encoding="utf-8"?>' . "\n";
    echo '<!DOCTYPE HTML>
<html lang="en" dir="ltr">
<head>
<link rel="icon" href="../favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
<meta charset="utf-8">
<title>Loading...</title>
<style>
@import url("https://fonts.googleapis.com/css2?family=Roboto:wght@500&display=swap");

body {
    background-color: black;
    color: white;
    font-family: \'Roboto\', sans-serif;
}

h1 {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: full;
}
</style>
</head>
<body>';
    if (isset($_SESSION['PMA_single_signon_error_message'])) {
        echo '<h1>';
        echo $_SESSION['PMA_single_signon_error_message'];
        echo '</h1>';
    } else {
        echo '<h1>You are not logged in, please try again.</h1>';
    }
    echo '</body>
    </html>';
}
?>
