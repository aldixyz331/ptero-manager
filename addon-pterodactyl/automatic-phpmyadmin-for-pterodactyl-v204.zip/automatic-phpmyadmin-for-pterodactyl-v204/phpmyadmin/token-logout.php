<?php
    // Must be the same as in the token.php file
    $session_name = 'TokenSession';
    session_name($session_name);
    @session_start();
    session_unset();
    session_destroy();
    echo '<script>window.close();</script>';
?>
